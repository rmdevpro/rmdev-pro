As the Senior Developer, I've carefully reviewed the feedback from all four Juniors. The two critical issues—the lack of an iframe-capable artifact viewer and the absence of workflow orchestration tests—were valid and have been prioritized. I have also incorporated the additional feedback where it was reasonable and aligned with the project's current goals.

This revised implementation addresses all noted deficiencies. The artifact viewer now correctly renders rich content like HTML, and a comprehensive integration test for the core `Genesis -> Synthesis -> Review` workflow has been added to ensure system stability. Additional comments, improved setup logic, and notes on future deployment options have also been included.

Here is the **complete and final implementation for Blueprint v2.0.1, Round 3**. All files are provided in their entirety.

---

### File: `blueprint/config.yaml`

```yaml
# Blueprint v2.0.1 Configuration
# This file defines the AI team, workflow settings, and API keys.
# Run `python -m blueprint.setup.berners_lee` for a guided setup.
# API keys should be set in the .env file and are loaded automatically.

# The team of AI agents that will build the digital asset.
# Using diverse models from different providers is recommended for best results.
team:
  # The Project Manager interacts with the user to define requirements.
  # Recommended: A model with strong conversational and reasoning abilities.
  project_manager: "anthropic/claude-3-5-sonnet-20240620"

  # The Senior Developer synthesizes junior outputs and refines based on feedback.
  # Recommended: A top-tier model with excellent synthesis and coding skills.
  senior: "google/gemini-1.5-pro-latest"

  # Junior Developers work in parallel to create initial implementations.
  # Configure between 2 and 5 juniors.
  juniors:
    count: 3
    models:
      - "together/deepseek-ai/deepseek-coder-v2-instruct" # Strong coder
      - "openai/gpt-4o"                                   # All-around powerhouse
      - "google/gemini-1.5-flash-latest"                  # Fast with a large context window

# Workflow settings control the build process.
workflow:
  # Number of Genesis rounds for cross-pollination. 1-3 recommended.
  genesis_rounds: 2
  # Maximum number of Synthesis/Review loops to attempt before failing.
  max_review_loops: 5
  # Approval threshold for the review phase. 1.0 means 100% of juniors must approve.
  approval_threshold: 1.0
  # Maximum retry attempts for a failing LLM call.
  max_retries: 3

# Output settings for the final deliverable.
output:
  # Path for all generated projects, relative to the application's root.
  path: "projects"

# Paths to the context files that define the behavior of each role.
context_paths:
  project_manager: "blueprint/contexts/project_manager.md"
  senior: "blueprint/contexts/senior_developer.md"
  junior: "blueprint/contexts/junior_developer.md"
  setup_manager: "blueprint/contexts/setup_manager.md"
```
---
### File: `blueprint/contexts/project_manager.md`

```md
# Role: Project Manager

You are the Project Manager for Blueprint, a system that creates digital assets using a team of AI developers. Your role is to engage in a conversation with the user to elicit a complete and clear set of requirements.

## Your Core Responsibilities:

1.  **Conversational Requirements Gathering**:
    -   Your primary goal is to have a natural, helpful conversation with the user.
    -   Start by greeting them and asking what they would like to build.
    -   Ask clarifying questions to resolve ambiguities. For example, if they ask for a "website," ask what kind of website, what pages it should have, what technology it should use, etc.
    -   Acknowledge and incorporate information from user-provided text, audio transcriptions, and file attachments into the conversation.
    -   Guide the user to provide all necessary details.
    -   Do NOT summarize the conversation. The entire verbatim transcript is the requirements document.

2.  **Concluding the Conversation**:
    -   Once you believe the requirements are complete, confirm with the user. You can say something like, "This looks like a solid plan. Are you ready for me to hand this off to the development team?"
    -   The user will signal the end of the conversation by saying something like "yes", "proceed", "start the build", or by using a command like `/build`.

3.  **Generating Instructions for the Team**:
    -   After the conversation is complete, your final task is to generate a brief set of instructions for the development team.
    -   This is NOT a summary of the requirements. It is a high-level directive.
    -   Your entire final output must be ONLY a JSON object with the key "instructions_for_dev_team".

## Example Interaction:

**User**: "I want to make a snake game."
**User (Audio Transcription)**: "It should use Python and Pygame."
**User (File Attachment `specs.txt`)**: "High score must be saved to a file."

**You**: "Great! A classic snake game is a fun project. Based on your input, we'll build it with Python and Pygame, and it will save the high score to a file. To make sure the team builds exactly what you want, could you clarify what should happen when the snake hits a wall or itself?"

**User**: "The game should end and display the final score."

**You**: "Perfect. That gives the team a clear direction. Are you ready for me to start the build process?"

**User**: "Yes, go ahead."

**You**:
```json
{
  "instructions_for_dev_team": "Build a classic Snake game using Python and the Pygame library, as detailed in the preceding conversation. The game must track high scores saved to a file and handle game-over conditions correctly."
}
```

**CRITICAL**: Your final response in the conversation MUST be ONLY the JSON object shown above. Do not include any other text, conversational filler, or markdown formatting.
```
---
### File: `blueprint/contexts/senior_developer.md`

```md
# Role: Senior Developer

You are the Senior Developer and technical lead of the Blueprint team. You are an expert in software architecture, code quality, and synthesis. You are responsible for creating high-quality initial implementations and, most importantly, for synthesizing the work of the entire team into a single, superior product.

## Your Core Responsibilities:

1.  **Genesis Phase**:
    -   You will receive an anchor context containing the user's requirements (as a conversation, including text, audio transcriptions, and file contents) and instructions from the Project Manager.
    -   Your task is to create your own complete, independent solution based on this context. This serves as a high-quality baseline for the Synthesis phase.
    -   Your output must be a complete set of files that fulfill the request.

2.  **Synthesis Phase**:
    -   This is your most critical responsibility. You will receive an anchor context containing the original requirements, PM instructions, and ALL solutions created by yourself and the Junior Developers during the Genesis phase.
    -   Your task is to analyze all submissions to identify the best ideas, code structures, algorithms, and implementation details.
    -   You must merge, refactor, and combine these ideas into a single, cohesive, and superior solution.
    -   **Do not simply pick one solution.** Your goal is to create a NEW synthesized artifact that is better than any individual submission.
    -   The final product should be a polished, production-ready deliverable.

3.  **Revision Phase (After Junior Review)**:
    -   You will receive an anchor context containing the original requirements, your previously synthesized solution, and a list of critiques and change requests from the Junior Developers.
    -   Your task is to review the feedback and revise your synthesized solution to address the valid points.
    -   You have the authority to reject feedback if it conflicts with the original user requirements. If you do, you must provide a brief justification in a comment within the relevant code file. For example: `// Junior #2's suggestion to use a NoSQL database was rejected as the requirements imply a relational data structure.`
    -   Your goal is to produce a final version that the entire team can agree on.

## Output Format for ALL Phases:

**CRITICAL**: You must write ALL generated files directly in your response using markdown code blocks. Use this exact format, with no conversational text outside the code blocks:

```
## File: path/to/filename.ext
\`\`\`language
file contents here
\`\`\`

## File: another/file.ext
\`\`\`language
another file's contents
\`\`\`
```

**CRITICAL RULES**:
-   Always write COMPLETE, WORKING CODE.
-   Include ALL necessary files (e.g., main code, tests, README, requirements.txt, Dockerfile).
-   Ensure your solution is self-contained and production-ready.
-   Adhere strictly to the `## File:` format.
```
---
### File: `blueprint/contexts/junior_developer.md`

```md
# Role: Junior Developer

You are a Junior Developer on the Blueprint team. You are a skilled and creative professional tasked with generating a complete solution based on requirements and reviewing the final synthesized product.

## Your Core Responsibilities:

### 1. Genesis Phase (Creation)

You will receive an anchor context containing user requirements (as a conversation, including text, audio transcriptions, and file contents) and instructions from the Project Manager. For later Genesis rounds, you will also receive the outputs from all team members from the previous round.

-   **Task**: Create a complete, fully-realized version of the requested digital asset.
-   **First Round**: Work independently and creatively based on the initial requirements.
-   **Subsequent Rounds**: Analyze the work from your peers in the previous round. Incorporate the best ideas into your new version while still exploring your own creative solutions. This is for cross-pollination.
-   **Output**: Your response must be a complete set of files that fulfill the request.

**Output Format for Genesis Phase (MANDATORY)**:
You must write ALL generated files using markdown code blocks. Use this exact format:
```
## File: path/to/filename.ext
\`\`\`language
file contents here
\`\`\`
```

### 2. Review Phase (Critique)

After the Genesis and Synthesis phases, you will be asked to review the final, consolidated solution created by the Senior Developer.

-   **Task**: Critique the synthesized solution. Your goal is to help improve it and ensure it meets the user's requirements.
-   **Analyze**: Compare the Senior's solution against the original user requirements. Is it complete? Is it correct? Is the code high quality?
-   **Output**: Your entire response must be a single JSON object. Do not include any other text or markdown.

**JSON Output Format for Review Phase (MANDATORY)**:
```json
{
  "approved": boolean,
  "critique": "Your detailed critique and reasoning here. If not approved, list specific, actionable changes you want to see. If approved, state why you think it's a good solution."
}
```

-   `approved`: `true` if you believe the solution is complete, correct, and meets the requirements. `false` otherwise.
-   `critique`: A clear, constructive explanation.
    -   If `false`, you MUST provide specific changes. E.g., "The database connection is not properly closed in `db.py`. Please add a `finally` block to ensure `conn.close()` is called. Also, the `README.md` is missing installation instructions."
    -   If `true`, briefly explain why. E.g., "The solution is elegant, well-documented, and fully implements all features from the requirements."

**CRITICAL**: Adhere to the specified output formats for each phase. Incorrect formatting will cause the system to fail.
```
---
### File: `blueprint/contexts/setup_manager.md`

```md
# Role: Setup Manager "Tim Berners-Lee"

You are a helpful and visionary guide, embodying the spirit of Tim Berners-Lee. Your purpose is to assist the user in configuring their `config.yaml` file for the Blueprint system. You are patient, knowledgeable, and slightly whimsical, with a deep appreciation for the potential of collaborative systems.

## Your Guiding Principles:

1.  **Be Conversational and Engaging**: Don't just spit out facts. Ask the user questions. Explain the *why* behind each setting. Use analogies related to building the web, collaboration, and information sharing.
2.  **Explain, Then Ask**: For each section (`team`, `workflow`, etc.), first explain its purpose and the significance of its settings. Then, ask the user for their preferences or confirm the defaults.
3.  **Provide Smart Recommendations**: Use the provided list of available models to make informed suggestions. For instance, "For the Project Manager, you'll want a model that's excellent at conversation and reasoning. From the available models, I see `claude-3-5-sonnet-20240620`, which is a fantastic choice. The default is set to that. Does that sound good, or do you have another model in mind?"
4.  **Validate and Guide**: If the user provides an invalid choice (e.g., only 1 junior developer), gently correct them. "Ah, for a truly collaborative effort, we need at least two Junior Developers to bounce ideas off each other. Shall we set the count to 2?"
5.  **Maintain State**: Keep track of the user's choices throughout the conversation.
6.  **Final Output**: Once the conversation is complete, your *entire final output* must be the complete, valid `config.yaml` file, enclosed in a single YAML markdown block. Do not include any other text, pleasantries, or explanations in your final message.

## Example Snippet of Interaction:

**You**: "Splendid! Let's start weaving the fabric of your AI team. First, the **Project Manager**. This agent is your primary contact, the one who chats with you to understand your vision. We need a model with a good 'bedside manner' and strong reasoning. The default is `anthropic/claude-3-5-sonnet-20240620`. Are you happy with that, or would you like to specify a different one?"

**User**: "That's fine."

**You**: "Excellent choice. Now, for the **Senior Developer**. This is the technical lead, the one who synthesizes all the work into a final product. This requires a powerful, top-tier model. We've set it to `google/gemini-1.5-pro-latest`, which has a massive context window, perfect for reviewing lots of code. How does that sit with you?"

**(Conversation continues...)**

**User**: "Looks great, let's finalize it."

**You**:
```yaml
# Blueprint v2.0.1 Configuration
# ... (complete YAML content based on the conversation) ...
```
```
---
### File: `blueprint/frontend/index.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blueprint v2.0.1</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <button id="newProjectBtn" class="new-project-btn">+ New Project</button>
            <h2>Projects</h2>
            <ul id="projectList">
                <!-- Projects will be loaded here -->
            </ul>
        </aside>
        <main class="main-content">
            <div id="welcomeScreen">
                <h1>Blueprint v2.0.1</h1>
                <p>Click "New Project" to start building.</p>
            </div>
            <div id="chatScreen" class="hidden">
                <div id="chatLog"></div>
                <div id="pmTypingIndicator" class="typing-indicator hidden">
                    <span></span><span></span><span></span>
                </div>
                <div id="buildStatus" class="build-status hidden"></div>
                <form id="chatForm">
                    <div class="input-area">
                        <textarea id="userInput" placeholder="Chat with the Project Manager to define your project..."></textarea>
                        <div class="input-buttons">
                            <button type="button" id="recordBtn" title="Record Audio">🎤</button>
                            <button type="button" id="attachBtn" title="Attach File">📎</button>
                            <input type="file" id="fileInput" class="hidden"/>
                        </div>
                    </div>
                    <button type="submit" id="sendBtn">Send</button>
                </form>
            </div>
        </main>
        <aside id="artifactViewer" class="artifact-viewer hidden">
             <div class="artifact-header">
                <h3>Artifacts</h3>
                <button id="closeArtifactsBtn">&times;</button>
            </div>
            <div id="artifactTabs"></div>
            <div id="artifactContent" class="artifact-content-container">
                <!-- Content (iframe or pre/code) will be injected here -->
            </div>
        </aside>
    </div>
    <script src="app.js"></script>
</body>
</html>
```
---
### File: `blueprint/frontend/styles.css`

```css
:root {
    --bg-color: #1a1a1a;
    --sidebar-bg: #2a2a2a;
    --main-bg: #202020;
    --text-color: #e0e0e0;
    --primary-color: #007bff;
    --border-color: #444;
    --input-bg: #333;
    --button-hover: #0056b3;
    --success: #28a745;
    --error: #dc3545;
    --inprogress: #ffc107;
    --disabled-color: #555;
}

* { box-sizing: border-box; }

body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background-color: var(--bg-color);
    color: var(--text-color);
    margin: 0;
    height: 100vh;
    overflow: hidden;
}

.container {
    display: flex;
    height: 100%;
}

/* Sidebar */
.sidebar {
    width: 250px;
    background-color: var(--sidebar-bg);
    padding: 1rem;
    display: flex;
    flex-direction: column;
    border-right: 1px solid var(--border-color);
}
.new-project-btn {
    background-color: var(--primary-color);
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    margin-bottom: 1rem;
    font-size: 1rem;
}
.new-project-btn:hover { background-color: var(--button-hover); }
.sidebar h2 { font-size: 1.1rem; margin-top: 0; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; }
#projectList { list-style: none; padding: 0; margin: 0; overflow-y: auto; }
#projectList li { padding: 10px; cursor: pointer; border-radius: 5px; margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#projectList li:hover { background-color: #383838; }
#projectList li.active { background-color: var(--primary-color); }

/* Main Content */
.main-content {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    background-color: var(--main-bg);
}
#welcomeScreen { text-align: center; margin: auto; }
#chatScreen { display: flex; flex-direction: column; height: 100%; }
#chatLog { flex-grow: 1; padding: 1rem; overflow-y: auto; }
.message { max-width: 80%; margin-bottom: 1rem; padding: 10px 15px; border-radius: 10px; line-height: 1.5; }
.user-message { background-color: var(--primary-color); color: white; align-self: flex-end; margin-left: auto; border-bottom-right-radius: 0; }
.pm-message { background-color: var(--sidebar-bg); align-self: flex-start; border-bottom-left-radius: 0; }
.system-message { text-align: center; color: #aaa; font-style: italic; margin: 1rem 0; font-size: 0.9em; }

/* Chat Form & Inputs */
#chatForm { display: flex; padding: 1rem; border-top: 1px solid var(--border-color); gap: 10px; }
.input-area { flex-grow: 1; display: flex; background-color: var(--input-bg); border: 1px solid var(--border-color); border-radius: 5px; }
#userInput { flex-grow: 1; background-color: transparent; color: var(--text-color); border: none; border-radius: 5px; padding: 10px; resize: none; font-size: 1rem; }
#userInput:focus { outline: none; }
.input-buttons { display: flex; align-items: center; padding-right: 5px; }
.input-buttons button { background: none; border: none; color: var(--text-color); font-size: 1.2rem; cursor: pointer; padding: 5px; }
.input-buttons button:hover { color: var(--primary-color); }
.input-buttons button.recording { color: var(--error); }
#sendBtn { background-color: var(--primary-color); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer; }
#sendBtn:hover { background-color: var(--button-hover); }
#sendBtn:disabled { background-color: var(--disabled-color); cursor: not-allowed; }

/* PM Typing Indicator */
.typing-indicator { align-self: flex-start; margin: 0 1rem 1rem; padding: 10px 15px; background-color: var(--sidebar-bg); border-radius: 10px; border-bottom-left-radius: 0; }
.typing-indicator span { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: #888; margin: 0 2px; animation: bounce 1.4s infinite ease-in-out both; }
.typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
.typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
@keyframes bounce { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1.0); } }

/* Build Status */
.build-status { padding: 1rem; border-top: 1px solid var(--border-color); background-color: #2a2a2a; }
.phase-list { list-style: none; padding: 0; margin: 0; }
.phase-list li { display: flex; align-items: center; gap: 1rem; padding: 0.5rem 0; }
.status-icon { font-size: 1.2rem; }
.status-icon.complete { color: var(--success); }
.status-icon.in-progress { color: var(--inprogress); animation: spin 1s linear infinite; }
.status-icon.failed { color: var(--error); }
.status-icon.pending { color: #666; }
@keyframes spin { 100% { transform: rotate(360deg); } }
.phase-name { font-weight: bold; }
.phase-details { color: #aaa; font-size: 0.9em; }

/* Artifact Viewer */
.artifact-viewer { width: 40%; max-width: 600px; background-color: var(--sidebar-bg); border-left: 1px solid var(--border-color); display: flex; flex-direction: column; }
.artifact-header { display: flex; justify-content: space-between; align-items: center; padding: 1rem; border-bottom: 1px solid var(--border-color); }
#closeArtifactsBtn { background: none; border: none; color: var(--text-color); font-size: 1.5rem; cursor: pointer; }
#artifactTabs { display: flex; flex-wrap: wrap; padding: 0.5rem; border-bottom: 1px solid var(--border-color); }
.tab { padding: 5px 10px; background-color: var(--input-bg); border-radius: 5px; margin: 2px; cursor: pointer; font-size: 0.9em; }
.tab.active { background-color: var(--primary-color); }
.artifact-content-container { flex-grow: 1; padding: 1rem; overflow: auto; background-color: var(--bg-color); }
.artifact-content-container iframe { width: 100%; height: 100%; border: none; background-color: #fff; }
.artifact-content-container pre { margin: 0; white-space: pre-wrap; word-wrap: break-word; font-family: "Courier New", Courier, monospace; font-size: 0.9em; }
.artifact-content-container code { color: var(--text-color); }

.hidden { display: none !important; }
```
---
### File: `blueprint/frontend/app.js`

```javascript
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const newProjectBtn = document.getElementById('newProjectBtn');
    const projectList = document.getElementById('projectList');
    const welcomeScreen = document.getElementById('welcomeScreen');
    const chatScreen = document.getElementById('chatScreen');
    const chatLog = document.getElementById('chatLog');
    const chatForm = document.getElementById('chatForm');
    const userInput = document.getElementById('userInput');
    const sendBtn = document.getElementById('sendBtn');
    const recordBtn = document.getElementById('recordBtn');
    const attachBtn = document.getElementById('attachBtn');
    const fileInput = document.getElementById('fileInput');
    const pmTypingIndicator = document.getElementById('pmTypingIndicator');
    const buildStatusContainer = document.getElementById('buildStatus');
    const artifactViewer = document.getElementById('artifactViewer');
    const closeArtifactsBtn = document.getElementById('closeArtifactsBtn');
    const artifactTabs = document.getElementById('artifactTabs');
    const artifactContent = document.getElementById('artifactContent');

    // State
    let ws;
    let currentProject = null;
    let projects = {};
    let mediaRecorder;
    let audioChunks = [];
    let isRecording = false;
    let currentBlobUrl = null;

    const WS_URL = `ws${window.location.protocol === 'https:' ? 's' : ''}://${window.location.host}/ws`;

    // --- WebSocket Management ---
    function connectWebSocket() {
        ws = new WebSocket(WS_URL);
        ws.onopen = () => console.log('WebSocket connected');
        ws.onclose = (event) => {
            console.log(`WebSocket disconnected: ${event.code}. Reconnecting...`);
            // Implement more specific error handling based on close codes if needed
            // e.g., 1006 (Abnormal Closure) is common on dev server reloads
            if (event.code !== 1000) { // 1000 is normal closure
                 addMessageToChatLog('system-message', 'Connection lost. Attempting to reconnect...');
            }
            setTimeout(connectWebSocket, 3000);
        };
        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            addMessageToChatLog('system-message', 'A connection error occurred.');
        };
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        };
    }

    function handleWebSocketMessage(data) {
        if (data.project_id !== currentProject) return;

        setUIState('idle');

        switch (data.type) {
            case 'pm_message':
                addMessageToChatLog('pm-message', data.message);
                projects[currentProject].chatHistory.push({ type: 'pm-message', text: data.message });
                break;
            case 'build_progress':
                updateBuildStatus(data.payload);
                break;
            case 'build_complete':
                showFinalArtifacts(data.payload);
                setUIState('build_complete');
                break;
            case 'error':
                addMessageToChatLog('system-message', `Error: ${data.message}`);
                break;
        }
    }

    // --- UI State Management ---
    function setUIState(state) {
        pmTypingIndicator.classList.add('hidden');
        userInput.disabled = false;
        sendBtn.disabled = false;
        recordBtn.disabled = false;
        attachBtn.disabled = false;

        if (state === 'waiting_for_pm') {
            pmTypingIndicator.classList.remove('hidden');
            userInput.disabled = true;
            sendBtn.disabled = true;
            recordBtn.disabled = true;
            attachBtn.disabled = true;
        } else if (state === 'build_in_progress' || state === 'build_complete') {
             userInput.disabled = true;
             sendBtn.disabled = true;
             recordBtn.disabled = true;
             attachBtn.disabled = true;
             userInput.placeholder = state === 'build_complete' 
                ? "Build complete. Start a new project to continue."
                : "Build in progress...";
        }
    }

    // --- UI Update Functions ---
    function addMessageToChatLog(type, text, meta = '') {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = text;
        if (meta) {
            const metaSpan = document.createElement('span');
            metaSpan.className = 'meta';
            metaSpan.textContent = meta;
            messageDiv.prepend(metaSpan);
        }
        chatLog.appendChild(messageDiv);
        chatLog.scrollTop = chatLog.scrollHeight;
    }

    function updateBuildStatus(status) {
        buildStatusContainer.classList.remove('hidden');
        setUIState('build_in_progress');
        let html = `<h4>Build Progress</h4><ul class="phase-list">`;
        status.phases.forEach(phase => {
            let icon = '⚪';
            let iconClass = 'pending';
            if (phase.status === 'complete') { icon = '✅'; iconClass = 'complete'; }
            if (phase.status === 'in_progress') { icon = '🔄'; iconClass = 'in-progress'; }
            if (phase.status === 'failed') { icon = '❌'; iconClass = 'failed'; }
            html += `<li>
                <span class="status-icon ${iconClass}">${icon}</span>
                <span class="phase-name">${phase.name}</span>
                <span class="phase-details">${phase.details || ''}</span>
            </li>`;
        });
        html += `</ul>`;
        buildStatusContainer.innerHTML = html;
    }
    
    function showFinalArtifacts(artifacts) {
        projects[currentProject].artifacts = artifacts;
        artifactViewer.classList.remove('hidden');
        artifactTabs.innerHTML = '';
        artifactContent.innerHTML = '';
        const filenames = Object.keys(artifacts);
        if (filenames.length === 0) return;

        filenames.forEach((filename) => {
            const tab = document.createElement('div');
            tab.className = 'tab';
            tab.textContent = filename;
            tab.dataset.filename = filename;
            artifactTabs.appendChild(tab);
        });

        // Activate the first tab
        const firstTab = artifactTabs.querySelector('.tab');
        if (firstTab) {
            firstTab.classList.add('active');
            renderArtifact(firstTab.dataset.filename);
        }
    }

    function renderArtifact(filename) {
        const content = projects[currentProject].artifacts[filename];
        const extension = filename.split('.').pop().toLowerCase();
        
        // Revoke the previous blob URL to prevent memory leaks
        if (currentBlobUrl) {
            URL.revokeObjectURL(currentBlobUrl);
            currentBlobUrl = null;
        }
        artifactContent.innerHTML = '';

        const renderableExtensions = {
            'html': 'text/html',
            'pdf': 'application/pdf',
            'png': 'image/png',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'gif': 'image/gif',
            'svg': 'image/svg+xml'
        };

        if (renderableExtensions[extension]) {
            const iframe = document.createElement('iframe');
            if (extension === 'html') {
                // For HTML, we can use srcdoc for better security and simplicity
                iframe.srcdoc = content;
            } else {
                // For other types like PDF/images, blob URL is necessary
                const blob = new Blob([content], { type: renderableExtensions[extension] });
                currentBlobUrl = URL.createObjectURL(blob);
                iframe.src = currentBlobUrl;
            }
            artifactContent.appendChild(iframe);
        } else {
            // Fallback for plain text, code, etc.
            const pre = document.createElement('pre');
            const code = document.createElement('code');
            code.textContent = content;
            pre.appendChild(code);
            artifactContent.appendChild(pre);
        }
    }

    // --- Project Management ---
    function createNewProject() {
        const projectId = `proj_${new Date().getTime()}`;
        currentProject = projectId;
        projects[currentProject] = {
            id: projectId,
            title: `New Project - ${new Date().toLocaleTimeString()}`,
            chatHistory: [],
            artifacts: null
        };
        ws.send(JSON.stringify({ type: 'start_project', project_id: projectId }));
        
        updateProjectList();
        switchToProject(projectId);
    }
    
    function switchToProject(projectId) {
        currentProject = projectId;
        
        welcomeScreen.classList.add('hidden');
        chatScreen.classList.remove('hidden');
        chatLog.innerHTML = '';
        buildStatusContainer.classList.add('hidden');
        artifactViewer.classList.add('hidden');
        userInput.value = '';
        userInput.placeholder = "Chat with the Project Manager to define your project...";
        
        const project = projects[projectId];
        project.chatHistory.forEach(msg => addMessageToChatLog(msg.type, msg.text));
        
        if (project.artifacts) {
            showFinalArtifacts(project.artifacts);
            setUIState('build_complete');
        } else {
            setUIState('waiting_for_pm');
        }
        
        updateProjectList();
    }

    function updateProjectList() {
        projectList.innerHTML = '';
        Object.values(projects).forEach(proj => {
            const li = document.createElement('li');
            li.textContent = proj.title;
            li.dataset.projectId = proj.id;
            if (proj.id === currentProject) {
                li.classList.add('active');
            }
            projectList.appendChild(li);
        });
    }

    // --- Media Handling ---
    async function toggleRecording() {
        if (isRecording) {
            mediaRecorder.stop();
            isRecording = false;
            recordBtn.classList.remove('recording');
            recordBtn.textContent = '🎤';
        } else {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
                mediaRecorder.onstop = sendAudio;
                audioChunks = [];
                mediaRecorder.start();
                isRecording = true;
                recordBtn.classList.add('recording');
                recordBtn.textContent = '🛑';
            } catch (err) {
                console.error("Error accessing microphone:", err);
                addMessageToChatLog('system-message', "Could not access microphone.");
            }
        }
    }

    function sendAudio() {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = reader.result.split(',')[1];
            ws.send(JSON.stringify({
                type: 'user_audio',
                project_id: currentProject,
                audio_data: base64String,
                mime_type: 'audio/webm'
            }));
            addMessageToChatLog('user-message', '[Sent audio message]');
            projects[currentProject].chatHistory.push({ type: 'user-message', text: '[Sent audio message]' });
            setUIState('waiting_for_pm');
        };
        reader.readAsDataURL(audioBlob);
    }
    
    function handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const base64String = e.target.result.split(',')[1];
            ws.send(JSON.stringify({
                type: 'user_file',
                project_id: currentProject,
                file_data: base64String,
                filename: file.name
            }));
            addMessageToChatLog('user-message', `[Attached file: ${file.name}]`);
            projects[currentProject].chatHistory.push({ type: 'user-message', text: `[Attached file: ${file.name}]` });
            setUIState('waiting_for_pm');
        };
        reader.readAsDataURL(file);
        fileInput.value = ''; // Reset for next upload
    }

    // --- Event Listeners ---
    newProjectBtn.addEventListener('click', createNewProject);
    projectList.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') switchToProject(e.target.dataset.projectId);
    });
    recordBtn.addEventListener('click', toggleRecording);
    attachBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileUpload);
    closeArtifactsBtn.addEventListener('click', () => artifactViewer.classList.add('hidden'));

    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const messageText = userInput.value.trim();
        if (!messageText || !currentProject || sendBtn.disabled) return;

        addMessageToChatLog('user-message', messageText);
        projects[currentProject].chatHistory.push({ type: 'user-message', text: messageText });
        
        ws.send(JSON.stringify({
            type: 'user_message',
            project_id: currentProject,
            message: messageText
        }));
        
        userInput.value = '';
        setUIState('waiting_for_pm');

        if (messageText.toLowerCase().trim() === '/build') {
            addMessageToChatLog('system-message', 'Build process initiated...');
            setUIState('build_in_progress');
        }
    });
    
    artifactTabs.addEventListener('click', (e) => {
        if (e.target.classList.contains('tab')) {
            const filename = e.target.dataset.filename;
            renderArtifact(filename);
            document.querySelectorAll('#artifactTabs .tab').forEach(t => t.classList.remove('active'));
            e.target.classList.add('active');
        }
    });

    // --- Initialization ---
    connectWebSocket();
});
```
---
### File: `blueprint/src/main.py`

```python
import asyncio
import logging
import json
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from blueprint.src.workflow.orchestrator import ProjectOrchestrator
from blueprint.src.api.websocket import ConnectionManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - [%(name)s] - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Blueprint application starting up...")
    Path("projects").mkdir(exist_ok=True)
    yield
    logger.info("Blueprint application shutting down.")

app = FastAPI(
    title="Blueprint v2.0.1",
    description="Conversational Multi-Agent Development System",
    lifespan=lifespan
)

manager = ConnectionManager()
orchestrator = ProjectOrchestrator(manager)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    project_id = None
    try:
        while True:
            raw_data = await websocket.receive_text()
            try:
                data = json.loads(raw_data)
            except json.JSONDecodeError:
                logger.warning(f"Received invalid JSON from client: {raw_data}")
                await manager.send_error(websocket, None, "Invalid JSON format received.")
                continue
                
            logger.info(f"Received message of type '{data.get('type')}'")
            project_id = data.get("project_id")
            if not project_id:
                await manager.send_error(websocket, None, "Missing project_id in message.")
                continue

            msg_type = data.get('type')
            if msg_type == 'start_project':
                await orchestrator.start_project(project_id, websocket)
            elif msg_type == 'user_message':
                await orchestrator.handle_user_message(project_id, data['message'])
            elif msg_type == 'user_audio':
                await orchestrator.handle_user_audio(project_id, data)
            elif msg_type == 'user_file':
                await orchestrator.handle_user_file(project_id, data)
            else:
                await manager.send_error(websocket, project_id, f"Unknown message type: {msg_type}")

    except WebSocketDisconnect:
        manager.disconnect(websocket, project_id)
        logger.info(f"Client for project {project_id} disconnected.")
    except Exception as e:
        logger.error(f"WebSocket Error for project {project_id}: {e}", exc_info=True)
        if project_id:
             await manager.send_error(websocket, project_id, f"An unexpected server error occurred: {e}")


# Serve the frontend as static files
# This must be the last mount
app.mount("/", StaticFiles(directory="blueprint/frontend", html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    logger.info("Starting Blueprint server with Uvicorn...")
    uvicorn.run("blueprint.src.main:app", host="0.0.0.0", port=8000, reload=True)
```
---
### File: `blueprint/src/api/websocket.py`

```python
import logging
from typing import Dict, List, Any, Optional
from fastapi import WebSocket

logger = logging.getLogger(__name__)

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        logger.info("New client connected.")

    def disconnect(self, websocket: WebSocket, project_id: Optional[str]):
        if project_id and self.active_connections.get(project_id) == websocket:
            del self.active_connections[project_id]
            logger.info(f"Client for project {project_id} disconnected and unregistered.")
        else:
            # This can happen if a client connects but never starts a project
            logger.info("A client disconnected without a registered project.")

    def register_project_connection(self, project_id: str, websocket: WebSocket):
        self.active_connections[project_id] = websocket
        logger.info(f"Registered websocket for project {project_id}")

    async def _send_json(self, project_id: str, data: Dict[str, Any]):
        websocket = self.active_connections.get(project_id)
        if websocket:
            try:
                await websocket.send_json(data)
            except Exception as e:
                # This might happen if the connection is closed abruptly
                logger.error(f"Failed to send message to project {project_id}: {e}")
                self.disconnect(websocket, project_id)
        else:
            logger.warning(f"No active connection found for project {project_id}")

    async def send_pm_message(self, project_id: str, message: str):
        await self._send_json(project_id, {"type": "pm_message", "project_id": project_id, "message": message})

    async def send_progress_update(self, project_id: str, payload: Dict[str, Any]):
        await self._send_json(project_id, {"type": "build_progress", "project_id": project_id, "payload": payload})

    async def send_build_complete(self, project_id: str, artifacts: Dict[str, str]):
        await self._send_json(project_id, {"type": "build_complete", "project_id": project_id, "payload": artifacts})

    async def send_error(self, websocket: WebSocket, project_id: Optional[str], message: str):
        try:
            # Use the passed websocket object directly as it might not be registered yet
            await websocket.send_json({"type": "error", "project_id": project_id, "message": message})
        except Exception as e:
            logger.error(f"Failed to send error message to client: {e}")
```
---
### File: `blueprint/src/config/settings.py`

```python
import yaml
import os
import re
from pydantic import BaseModel, Field, ValidationError, field_validator
from typing import List, Optional
from dotenv import load_dotenv
import logging

logger = logging.getLogger(__name__)

# Assume the script is run from the root of the project.
CONFIG_PATH = "blueprint/config.yaml"

# --- Pydantic Models for Strong Typing and Validation ---

class ApiKeys(BaseModel):
    openai: Optional[str] = None
    google: Optional[str] = None
    together: Optional[str] = None
    xai: Optional[str] = None
    anthropic: Optional[str] = None

class JuniorsConfig(BaseModel):
    count: int = Field(..., ge=2, le=5)
    models: List[str]

    @field_validator('models')
    def check_models_count(cls, v, values):
        if 'count' in values.data and len(v) != values.data['count']:
            raise ValueError(f"The number of models ({len(v)}) must match the specified junior count ({values.data['count']}).")
        return v

class TeamConfig(BaseModel):
    project_manager: str
    senior: str
    juniors: JuniorsConfig

class WorkflowConfig(BaseModel):
    genesis_rounds: int = Field(..., ge=1, le=3)
    max_review_loops: int = Field(..., ge=1, le=10)
    approval_threshold: float = Field(..., ge=0.5, le=1.0)
    max_retries: int = Field(..., ge=1, le=5)

class OutputConfig(BaseModel):
    path: str

class ContextPathsConfig(BaseModel):
    project_manager: str
    senior: str
    junior: str
    setup_manager: str

class Settings(BaseModel):
    team: TeamConfig
    workflow: WorkflowConfig
    output: OutputConfig
    context_paths: ContextPathsConfig
    api_keys: ApiKeys = Field(default_factory=ApiKeys) # api_keys are loaded separately

def _env_replacer(match):
    """Replaces ${VAR} with environment variable content."""
    var_name = match.group(1)
    return os.environ.get(var_name, "")

def load_settings() -> Settings:
    """Loads, substitutes env vars, and validates the YAML configuration."""
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError(f"Configuration file not found at '{CONFIG_PATH}'. Ensure you are running from the project root.")

    with open(CONFIG_PATH, 'r') as f:
        raw_config_str = f.read()

    # Substitute environment variables (for potential future use, e.g., in paths)
    processed_config_str = re.sub(r'\$\{(\w+)\}', _env_replacer, raw_config_str)
    config_dict = yaml.safe_load(processed_config_str)

    try:
        settings_obj = Settings.model_validate(config_dict)
        # Load API keys from .env file
        load_dotenv()
        settings_obj.api_keys = ApiKeys(
            openai=os.getenv("OPENAI_API_KEY"),
            google=os.getenv("GOOGLE_API_KEY"),
            together=os.getenv("TOGETHER_API_KEY"),
            xai=os.getenv("XAI_API_KEY"),
            anthropic=os.getenv("ANTHROPIC_API_KEY"),
        )
        return settings_obj
    except ValidationError as e:
        logger.error(f"Configuration validation error: {e}")
        raise

settings = load_settings()
```
---
### File: `blueprint/src/llm/client.py`

```python
import os
import logging
from typing import Any, Dict, Optional, List, Tuple
from pathlib import Path

from openai import AsyncOpenAI
import google.generativeai as genai
import anthropic
from tenacity import retry, stop_after_attempt, wait_exponential, RetryError

from blueprint.src.config.settings import settings

logger = logging.getLogger(__name__)

class LLMClient:
    _clients: Dict[str, Any] = {}
    _context_cache: Dict[str, str] = {}

    def __init__(self, model_identifier: str):
        self.provider, self.model = self._parse_identifier(model_identifier)
        self.api_key = self._get_api_key()
        self._client = self._get_client()

    def _parse_identifier(self, identifier: str) -> Tuple[str, str]:
        try:
            provider, model = identifier.split('/', 1)
            return provider, model
        except ValueError:
            raise ValueError(f"Invalid model identifier format: '{identifier}'. Expected 'provider/model-name'.")

    def _get_api_key(self) -> str:
        key = getattr(settings.api_keys, self.provider, None)
        if not key:
            raise ValueError(f"API key for provider '{self.provider}' is not configured in .env file.")
        return key

    def _get_client(self):
        # Client key should be unique per provider and API key
        client_key = f"{self.provider}-{hash(self.api_key)}"
        if client_key in self._clients:
            return self._clients[client_key]

        client = None
        try:
            if self.provider == "openai":
                client = AsyncOpenAI(api_key=self.api_key)
            elif self.provider == "google":
                genai.configure(api_key=self.api_key)
                client = genai
            elif self.provider == "anthropic":
                client = anthropic.AsyncAnthropic(api_key=self.api_key)
            elif self.provider == "together":
                client = AsyncOpenAI(api_key=self.api_key, base_url="https://api.together.xyz/v1")
            elif self.provider == "xai":
                client = AsyncOpenAI(api_key=self.api_key, base_url="https://api.x.ai/v1")
            else:
                raise ValueError(f"Unsupported LLM provider: {self.provider}")
        except Exception as e:
            logger.error(f"Failed to initialize client for {self.provider}: {e}")
            raise

        self._clients[client_key] = client
        return client

    def get_context_from_file(self, role: str) -> str:
        if role in self._context_cache:
            return self._context_cache[role]
        
        context_path_str = getattr(settings.context_paths, role, None)
        if not context_path_str:
            raise ValueError(f"Context path for role '{role}' not found in config.")
        
        context_path = Path(context_path_str)
        if not context_path.exists():
            raise FileNotFoundError(f"Context file for role '{role}' not found at path: {context_path}")
            
        content = context_path.read_text(encoding='utf-8')
        self._context_cache[role] = content
        return content

    @retry(wait=wait_exponential(multiplier=1, min=2, max=60), stop=stop_after_attempt(settings.workflow.max_retries))
    async def generate(self, system_prompt: str, messages: List[Dict[str, str]]) -> str:
        logger.info(f"Invoking model {self.provider}/{self.model} for text generation...")
        try:
            if self.provider in ["openai", "together", "xai"]:
                response = await self._client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "system", "content": system_prompt}] + messages,
                )
                return response.choices[0].message.content or ""
            
            elif self.provider == "anthropic":
                response = await self._client.messages.create(
                    model=self.model,
                    system=system_prompt,
                    messages=messages,
                    max_tokens=8192, # Anthropic requires max_tokens
                )
                return response.content[0].text
            
            elif self.provider == "google":
                model_instance = self._client.GenerativeModel(model_name=self.model, system_instruction=system_prompt)
                response = await model_instance.generate_content_async(messages)
                return response.text

        except Exception as e:
            logger.error(f"LLM generation failed for model {self.provider}/{self.model}: {e}", exc_info=True)
            raise  # Reraise to trigger tenacity retry

        raise NotImplementedError(f"Generation for provider {self.provider} not implemented correctly.")

    @retry(wait=wait_exponential(multiplier=1, min=2, max=60), stop=stop_after_attempt(settings.workflow.max_retries))
    async def transcribe(self, audio_data: bytes, filename: str) -> str:
        logger.info(f"Invoking model {self.provider}/whisper-1 for transcription...")
        if self.provider != "openai":
            raise NotImplementedError("Transcription is only supported for the 'openai' provider with Whisper.")
        
        try:
            # The file tuple is (filename, file_data)
            transcription = await self._client.audio.transcriptions.create(
                model="whisper-1",
                file=(filename, audio_data)
            )
            return transcription.text
        except Exception as e:
            logger.error(f"Audio transcription failed: {e}", exc_info=True)
            raise
```
---
### File: `blueprint/src/media/transcription.py`

```python
import base64
import logging

from blueprint.src.llm.client import LLMClient

logger = logging.getLogger(__name__)

async def transcribe_audio(audio_data_b64: str, mime_type: str) -> str:
    """
    Decodes base64 audio and transcribes it using the configured provider.
    Currently hardcoded to use OpenAI's Whisper model.
    """
    try:
        audio_bytes = base64.b64decode(audio_data_b64)
        
        # Determine file extension from mime type
        extension = mime_type.split('/')[-1]
        filename = f"audio_input.{extension}"

        # We need an OpenAI client specifically for transcription
        # The model identifier is hardcoded as Whisper is the de facto standard
        # and tied to the OpenAI client library implementation.
        client = LLMClient("openai/whisper-1")
        
        transcript = await client.transcribe(audio_bytes, filename)
        logger.info(f"Transcription successful. Transcript: '{transcript[:50]}...'")
        return transcript
    except Exception as e:
        logger.error(f"Error during audio transcription process: {e}", exc_info=True)
        return "[Error: Could not transcribe audio]"
```
---
### File: `blueprint/src/storage/filesystem.py`

```python
import logging
import re
from pathlib import Path
from typing import List, Dict

logger = logging.getLogger(__name__)

def parse_and_write_files(response_content: str, workspace_path: Path) -> List[str]:
    """
    Parses an LLM response for markdown code blocks and writes them to files.
    Format: ## File: path/to/filename.ext\n```lang\n...content...\n```
    """
    files_created = []
    workspace_path.mkdir(parents=True, exist_ok=True)
    
    # Regex to find file blocks, tolerant to variations in spacing and backticks
    pattern = r"##\s*File:\s*`?(.+?)`?\s*\n```(?:\w*\n)?(.*?)```"
    matches = re.findall(pattern, response_content, re.DOTALL)

    if not matches:
        logger.warning(f"No file blocks found in response for workspace {workspace_path}")
        # As a fallback, write the whole response to a single file
        fallback_path = workspace_path / "response.md"
        fallback_path.write_text(response_content, encoding='utf-8')
        files_created.append(str(fallback_path))
        return files_created

    for filename_str, content in matches:
        filename_str = filename_str.strip()
        # Basic sanitization to prevent directory traversal
        if ".." in filename_str or filename_str.startswith(('/', '\\')):
            logger.warning(f"Skipping potentially unsafe file path: {filename_str}")
            continue

        file_path = workspace_path / filename_str
        file_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            content_cleaned = content.strip()
            file_path.write_text(content_cleaned, encoding='utf-8')
            files_created.append(str(file_path))
            logger.info(f"Written file: {file_path}")
        except IOError as e:
            logger.error(f"Failed to write file {file_path}: {e}")

    return files_created

def format_files_for_context(workspace_path: Path) -> str:
    """Reads all files from a workspace and formats them for an LLM context."""
    context_str = ""
    if not workspace_path.is_dir():
        return "No files found in this submission."
        
    for path in sorted(workspace_path.rglob('*')):
        if path.is_file():
            try:
                content = path.read_text(encoding='utf-8')
                relative_path = path.relative_to(workspace_path)
                context_str += f"## File: {relative_path}\n```\n{content}\n```\n\n"
            except Exception as e:
                logger.warning(f"Could not read file {path} for context: {e}")
    return context_str

def get_project_files_as_dict(workspace_path: Path) -> Dict[str, str]:
    """Recursively reads all files from a workspace into a dictionary."""
    file_dict = {}
    if not workspace_path.is_dir():
        return {}
    
    for path in sorted(workspace_path.rglob('*')):
        if path.is_file():
            try:
                content = path.read_text(encoding='utf-8')
                relative_path = str(path.relative_to(workspace_path)).replace('\\', '/')
                file_dict[relative_path] = content
            except Exception as e:
                logger.warning(f"Could not read file {path} for artifact dictionary: {e}")
    return file_dict
```
---
### File: `blueprint/src/workflow/orchestrator.py`

```python
import asyncio
import logging
import json
import base64
from typing import Dict, List, Any
from pathlib import Path
from fastapi import WebSocket

from blueprint.src.api.websocket import ConnectionManager
from blueprint.src.config.settings import settings
from blueprint.src.llm.client import LLMClient
from blueprint.src.storage.filesystem import get_project_files_as_dict
from blueprint.src.media.transcription import transcribe_audio
from .phases import Phase, create_initial_phases

logger = logging.getLogger(__name__)

class Project:
    """Manages the state of a single project build."""
    def __init__(self, project_id: str, manager: ConnectionManager):
        self.id = project_id
        self.manager = manager
        self.websocket: WebSocket | None = None
        self.conversation_history: List[Dict[str, str]] = []
        self.anchor_context: Dict[str, Any] = {}
        self.phases: List[Phase] = create_initial_phases()
        self.project_path = Path(settings.output.path) / self.id
        self.project_path.mkdir(parents=True, exist_ok=True)
        self.build_started = False
        logger.info(f"Project {self.id} initialized at {self.project_path}")

    async def add_message(self, role: str, content: str):
        self.conversation_history.append({"role": role, "content": content})

    async def get_pm_response(self):
        pm_client = LLMClient(settings.team.project_manager)
        system_prompt = pm_client.get_context_from_file('project_manager')
        
        response_text = await pm_client.generate(system_prompt, self.conversation_history)
        await self.add_message("assistant", response_text)
        await self.manager.send_pm_message(self.id, response_text)

    async def run_build_workflow(self):
        logger.info(f"Starting build workflow for project {self.id}")
        # The final call to the Project Manager LLM is to get the structured instructions for the dev team.
        # This occurs after the user types `/build`.
        pm_client = LLMClient(settings.team.project_manager)
        system_prompt = pm_client.get_context_from_file('project_manager')
        pm_final_response = await pm_client.generate(system_prompt, self.conversation_history)
        
        try:
            # The PM is instructed to return ONLY a JSON object. We perform cleanup to handle
            # common LLM mistakes like adding markdown code blocks.
            json_str = pm_final_response.strip()
            if json_str.startswith("```json"):
                json_str = json_str.split("```json", 1)[1]
            if json_str.endswith("```"):
                json_str = json_str.rsplit("```", 1)[0]
            
            instructions_json = json.loads(json_str.strip())
            instructions = instructions_json.get("instructions_for_dev_team", "No instructions provided.")
        except (json.JSONDecodeError, AttributeError) as e:
            logger.error(f"PM failed to output valid JSON for instructions. Error: {e}. Raw response: {pm_final_response}")
            instructions = "Build the project based on the conversation."

        # The anchor context is the core set of documents that persists through all phases
        # to prevent "prompt drift".
        self.anchor_context['requirements_conversation'] = self.conversation_history
        self.anchor_context['pm_instructions'] = instructions

        # Execute each phase in sequence (Genesis -> Synthesis -> Review & Revise).
        for phase in self.phases:
            await self.update_phase_status(phase.name, "in_progress", f"Starting {phase.name} phase...")
            await phase.run(self)
            # After a phase runs successfully, update its status to complete.
            # The phase itself is responsible for updating its details during execution.
            await self.update_phase_status(phase.name, "complete", phase.details or f"{phase.name} phase complete.")
        
        # Once all phases are complete, retrieve the final artifacts and send them to the UI.
        final_artifacts = get_project_files_as_dict(self.project_path / "final_product")
        await self.manager.send_build_complete(self.id, final_artifacts)

    async def handle_build_exception(self, e: Exception):
        logger.error(f"Build workflow for {self.id} failed: {e}", exc_info=True)
        # Find which phase was running when the error occurred and mark it as failed.
        active_phase = next((p.name for p in self.phases if p.status == 'in_progress'), "Unknown")
        await self.update_phase_status(active_phase, "failed", str(e))
        if self.websocket:
            await self.manager.send_error(self.websocket, self.id, f"Build failed during {active_phase} phase: {e}")

    async def update_phase_status(self, phase_name: str, status: str, details: str = ""):
        for phase in self.phases:
            if phase.name == phase_name:
                phase.status = status
                phase.details = details
                break
        # Send the updated status of ALL phases to the UI.
        await self.manager.send_progress_update(self.id, {
            "phases": [p.to_dict() for p in self.phases]
        })


class ProjectOrchestrator:
    """Manages all active projects."""
    def __init__(self, manager: ConnectionManager):
        self.projects: Dict[str, Project] = {}
        self.manager = manager

    async def start_project(self, project_id: str, websocket: WebSocket):
        if project_id not in self.projects:
            project = Project(project_id, self.manager)
            project.websocket = websocket
            self.projects[project_id] = project
            self.manager.register_project_connection(project_id, websocket)
            # Greet the user and start the conversation.
            await project.get_pm_response()
        else:
             # This handles cases where a user might refresh the page, reconnecting the websocket
             # to an existing project.
             self.manager.register_project_connection(project_id, websocket)

    async def handle_user_message(self, project_id: str, message: str):
        project = self.projects.get(project_id)
        if not project: return
        
        await project.add_message("user", message)

        if message.lower().strip() == '/build' and not project.build_started:
            project.build_started = True
            # The build workflow is a long-running task, so we run it in the background
            # to avoid blocking the WebSocket connection.
            asyncio.create_task(self._safe_run_build(project))
        else:
            await project.get_pm_response()

    async def handle_user_audio(self, project_id: str, data: Dict):
        project = self.projects.get(project_id)
        if not project: return

        transcript = await transcribe_audio(data.get('audio_data'), data.get('mime_type'))
        await project.add_message("user", f"User audio transcription: {transcript}")
        await project.get_pm_response()

    async def handle_user_file(self, project_id: str, data: Dict):
        project = self.projects.get(project_id)
        if not project: return
        
        filename = data.get('filename', 'attached_file')
        try:
            # Attempt to decode as UTF-8 text. This is a simplification; a more robust
            # system might use a library like `python-magic` to detect file types.
            file_content = base64.b64decode(data.get('file_data')).decode('utf-8')
            msg = f"User attached file '{filename}':\n\n---\n{file_content}\n---"
        except Exception as e:
            logger.warning(f"Could not decode attached file {filename} as text. Attaching as metadata. Error: {e}")
            msg = f"[User attached a binary file named '{filename}']"
            
        await project.add_message("user", msg)
        await project.get_pm_response()

    async def _safe_run_build(self, project: Project):
        """Wrapper to run the build and catch any exceptions at the top level."""
        try:
            await project.run_build_workflow()
        except Exception as e:
            await project.handle_build_exception(e)
```
---
### File: `blueprint/src/workflow/phases.py`

```python
import asyncio
import logging
import json
import shutil
from typing import Dict, Any, List, TYPE_CHECKING
from pathlib import Path

from blueprint.src.config.settings import settings
from blueprint.src.llm.client import LLMClient
from blueprint.src.storage.filesystem import parse_and_write_files, format_files_for_context

if TYPE_CHECKING:
    from .orchestrator import Project

logger = logging.getLogger(__name__)

class Phase:
    def __init__(self, name: str):
        self.name = name
        self.status = "pending"  # pending, in_progress, complete, failed
        self.details = ""

    async def run(self, project: 'Project'):
        raise NotImplementedError

    def to_dict(self):
        return {"name": self.name, "status": self.status, "details": self.details}

class GenesisPhase(Phase):
    def __init__(self):
        super().__init__("Genesis")

    async def run(self, project: 'Project'):
        num_rounds = settings.workflow.genesis_rounds
        for i in range(1, num_rounds + 1):
            self.details = f"Round {i}/{num_rounds}"
            await project.update_phase_status(self.name, "in_progress", self.details)
            logger.info(f"Project {project.id}: Starting Genesis Round {i}")
            
            # Prepare the context prompt that will be sent to all developers.
            context_prompt = self._prepare_context(project, i)
            
            team_members = [settings.team.senior] + settings.team.juniors.models
            roles = ['senior'] + [f'junior_{j}' for j in range(settings.team.juniors.count)]
            
            # Run all developers in parallel for this round.
            tasks = []
            for role, model_id in zip(roles, team_members):
                client = LLMClient(model_id)
                system_prompt = client.get_context_from_file('senior' if role == 'senior' else 'junior')
                tasks.append(self._run_developer(client, system_prompt, context_prompt, project, role, i))
            
            await asyncio.gather(*tasks)
        self.details = f"{num_rounds} rounds completed."

    def _prepare_context(self, project: 'Project', round_num: int) -> str:
        # The context always starts with the original, verbatim requirements conversation.
        req_conv = "\n".join([f"<{msg['role']}>\n{msg['content']}\n</{msg['role']}>" for msg in project.anchor_context['requirements_conversation']])
        context = f"ORIGINAL REQUIREMENTS (Verbatim Conversation):\n---\n{req_conv}\n---\n\n"
        context += f"PROJECT MANAGER INSTRUCTIONS:\n---\n{project.anchor_context['pm_instructions']}\n---\n\n"
        
        # For rounds 2 and beyond, include all submissions from the previous round
        # for cross-pollination of ideas.
        if round_num > 1:
            context += "PREVIOUS ROUND SUBMISSIONS FOR CROSS-POLLINATION:\n---\n"
            prev_round = round_num - 1
            roles = ['senior'] + [f'junior_{j}' for j in range(settings.team.juniors.count)]
            for role in roles:
                role_path = project.project_path / f"genesis_round_{prev_round}" / role
                if role_path.exists():
                    context += f"Submission from {role}:\n"
                    context += format_files_for_context(role_path)
                    context += "\n"
            context += "---\n"
        return context

    async def _run_developer(self, client: LLMClient, system_prompt: str, user_prompt: str, project: 'Project', role: str, round_num: int):
        logger.info(f"Project {project.id}: Running {role} for Genesis Round {round_num}")
        response = await client.generate(system_prompt, [{"role": "user", "content": user_prompt}])
        output_path = project.project_path / f"genesis_round_{round_num}" / role
        parse_and_write_files(response, output_path)

class SynthesisPhase(Phase):
    def __init__(self):
        super().__init__("Synthesis")

    async def run(self, project: 'Project'):
        logger.info(f"Project {project.id}: Starting Synthesis")
        await project.update_phase_status(self.name, "in_progress", "Synthesizing solutions...")
        final_genesis_round = settings.workflow.genesis_rounds
        
        # Prepare context for the Senior Developer. This includes the original requirements
        # and ALL submissions from the final Genesis round.
        req_conv = "\n".join([f"<{msg['role']}>\n{msg['content']}\n</{msg['role']}>" for msg in project.anchor_context['requirements_conversation']])
        context = f"ORIGINAL REQUIREMENTS (Verbatim Conversation):\n---\n{req_conv}\n---\n\n"
        context += f"PROJECT MANAGER INSTRUCTIONS:\n---\n{project.anchor_context['pm_instructions']}\n---\n\n"
        context += "FINAL GENESIS SUBMISSIONS TO SYNTHESIZE:\n---\n"
        
        roles = ['senior'] + [f'junior_{j}' for j in range(settings.team.juniors.count)]
        for role in roles:
            role_path = project.project_path / f"genesis_round_{final_genesis_round}" / role
            context += f"Submission from {role}:\n{format_files_for_context(role_path)}\n"
        context += "---\n"
        
        client = LLMClient(settings.team.senior)
        system_prompt = client.get_context_from_file('senior')
        response = await client.generate(system_prompt, [{"role": "user", "content": context}])
        
        # The first synthesis output is saved as round 1.
        output_path = project.project_path / "synthesis_round_1"
        parse_and_write_files(response, output_path)
        self.details = "Initial synthesis complete."

class ReviewPhase(Phase):
    def __init__(self):
        super().__init__("Review & Revise")

    async def run(self, project: 'Project'):
        max_loops = settings.workflow.max_review_loops
        for i in range(1, max_loops + 1):
            self.details = f"Review Loop {i}/{max_loops}"
            await project.update_phase_status(self.name, "in_progress", self.details)
            logger.info(f"Project {project.id}: Starting Review Loop {i}")
            
            synthesized_path = project.project_path / f"synthesis_round_{i}"
            
            # Send the synthesized code to all juniors for critique.
            critiques = await self._get_junior_critiques(project, synthesized_path)
            
            approvals = [c.get('approved', False) for c in critiques]
            num_approved = sum(1 for a in approvals if a)
            
            # Check if the approval threshold is met.
            if num_approved / len(approvals) >= settings.workflow.approval_threshold:
                logger.info(f"Project {project.id}: Consensus reached in review loop {i}.")
                final_path = project.project_path / "final_product"
                if final_path.exists():
                    shutil.rmtree(final_path)
                shutil.copytree(synthesized_path, final_path)
                self.details = f"Consensus reached after {i} loops."
                return

            # If this was the last loop and consensus was not reached, the build fails.
            if i == max_loops:
                break 

            # If consensus is not reached, send the critiques back to the Senior for revision.
            await self._run_senior_revision(project, synthesized_path, critiques, i)

        raise Exception(f"Consensus not reached after {max_loops} review loops.")

    async def _get_junior_critiques(self, project: 'Project', synthesized_path: Path) -> List[Dict]:
        req_conv = "\n".join([f"<{msg['role']}>\n{msg['content']}\n</{msg['role']}>" for msg in project.anchor_context['requirements_conversation']])
        context = f"ORIGINAL REQUIREMENTS:\n---\n{req_conv}\n---\n\n"
        context += f"SYNTHESIZED SOLUTION TO REVIEW:\n---\n{format_files_for_context(synthesized_path)}\n---"
        
        tasks = []
        for model_id in settings.team.juniors.models:
            client = LLMClient(model_id)
            system_prompt = client.get_context_from_file('junior')
            tasks.append(client.generate(system_prompt, [{"role": "user", "content": context}]))
            
        responses = await asyncio.gather(*tasks)
        
        critiques = []
        for i, resp in enumerate(responses):
            try:
                # The junior is prompted to return JSON. We extract it robustly.
                json_str = resp[resp.find('{'):resp.rfind('}')+1]
                critique = json.loads(json_str)
                critiques.append(critique)
                logger.info(f"Project {project.id}: Junior {i} review: {critique}")
            except json.JSONDecodeError:
                logger.error(f"Project {project.id}: Junior {i} failed to provide valid JSON review. Response: {resp}")
                critiques.append({"approved": False, "critique": f"Failed to provide valid JSON. Raw response: {resp}"})
        return critiques

    async def _run_senior_revision(self, project: 'Project', synthesized_path: Path, critiques: List[Dict], loop_num: int):
        logger.info(f"Project {project.id}: Sending to Senior for revision.")
        await project.update_phase_status(self.name, "in_progress", f"Revising based on feedback (Loop {loop_num})")
        
        # Prepare context for the Senior, including the previous work and all junior feedback.
        req_conv = "\n".join([f"<{msg['role']}>\n{msg['content']}\n</{msg['role']}>" for msg in project.anchor_context['requirements_conversation']])
        context = f"ORIGINAL REQUIREMENTS:\n---\n{req_conv}\n---\n\n"
        context += f"YOUR PREVIOUSLY SYNTHESIZED SOLUTION:\n---\n{format_files_for_context(synthesized_path)}\n---\n\n"
        context += "JUNIOR DEVELOPER FEEDBACK (Address these points):\n---\n"
        for i, c in enumerate(critiques):
            approved_status = "APPROVED" if c.get('approved') else "NOT APPROVED"
            context += f"--- Junior #{i+1} ({approved_status}) ---\nCritique: {c.get('critique', 'No critique provided.')}\n"
        context += "---\n"
        
        client = LLMClient(settings.team.senior)
        system_prompt = client.get_context_from_file('senior')
        response = await client.generate(system_prompt, [{"role": "user", "content": context}])
        
        # The revised output is saved for the next review loop.
        output_path = project.project_path / f"synthesis_round_{loop_num + 1}"
        parse_and_write_files(response, output_path)

def create_initial_phases() -> List[Phase]:
    return [
        GenesisPhase(),
        SynthesisPhase(),
        ReviewPhase(),
    ]
```
---
### File: `blueprint/setup/berners_lee.py`

```python
import os
import sys
import yaml
import logging
import asyncio
from typing import List, Dict, Any

# Adjust path to import from sibling directories
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config.settings import CONFIG_PATH, settings
from src.llm.client import LLMClient

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class BColors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_color(color: str, message: str):
    print(f"{color}{message}{BColors.ENDC}")

async def fetch_available_models() -> str:
    """
    Fetches available models from configured providers to help the setup manager
    make better recommendations. This is a best-effort attempt.
    """
    # TODO: Implement hardware detection and recommend local models.
    # This would involve using a library like `psutil` to check VRAM/RAM
    # and then suggesting appropriate GGUF/Ollama models.
    
    model_info = "# Available Models from Providers (for recommendations):\n\n"
    
    # Example for OpenAI
    if settings.api_keys.openai:
        try:
            client = LLMClient("openai/gpt-4")._client # Access the underlying client
            models = await client.models.list()
            openai_models = [m.id for m in models if "gpt" in m.id]
            model_info += f"## OpenAI:\n- " + "\n- ".join(openai_models) + "\n\n"
        except Exception as e:
            model_info += f"## OpenAI:\n- Could not fetch models: {e}\n\n"

    # Example for Anthropic
    if settings.api_keys.anthropic:
        # The Anthropic library does not have a public model listing API.
        # We list common known models instead.
        model_info += "## Anthropic:\n- claude-3-5-sonnet-20240620\n- claude-3-opus-20240229\n- claude-3-sonnet-20240229\n- claude-3-haiku-20240307\n\n"

    # TODO: Add model fetchers for Google, Together, etc.
    
    return model_info

async def run_setup():
    print_color(BColors.HEADER, "--- Welcome to the Blueprint v2.0.1 Interactive Setup ---")
    print_color(BColors.HEADER, "I'm here to help you configure your AI development team.")
    print("\n")

    try:
        with open(CONFIG_PATH, 'r') as f:
            current_config = yaml.safe_load(f)
        print_color(BColors.OKCYAN, f"Loaded existing configuration from `{CONFIG_PATH}`.")
    except FileNotFoundError:
        print_color(BColors.WARNING, f"Could not find `{CONFIG_PATH}`. Starting with a default structure.")
        current_config = { 'team': {'juniors': {}}, 'workflow': {}, 'output': {}, 'context_paths': {} }
    
    print_color(BColors.OKBLUE, "Fetching available model information from providers...")
    available_models_md = await fetch_available_models()
    
    initial_prompt = (
        f"Here is my current config.yaml file. Please guide me through configuring it. "
        f"If a section is missing, please help me create it.\n\n"
        f"```yaml\n{yaml.dump(current_config)}\n```\n\n"
        f"Also, here is a list of models I seem to have access to. Use this to inform your recommendations.\n\n"
        f"{available_models_md}"
    )
    
    conversation_history: List[Dict[str, str]] = [ {"role": "user", "content": initial_prompt} ]

    try:
        # Use a powerful conversational model for the setup manager
        client = LLMClient("anthropic/claude-3-5-sonnet-20240620")
        system_prompt = client.get_context_from_file('setup_manager')
    except Exception as e:
        print_color(BColors.FAIL, f"Fatal Error: Could not initialize the setup assistant. Please ensure you have a valid ANTHROPIC_API_KEY in your .env file.")
        print_color(BColors.FAIL, f"Details: {e}")
        return

    while True:
        print_color(BColors.OKBLUE, "\nTim Berners-Lee is thinking...")
        
        try:
            response = await client.generate(system_prompt, conversation_history)
        except Exception as e:
            print_color(BColors.FAIL, f"An error occurred while communicating with the assistant: {e}")
            break

        conversation_history.append({"role": "assistant", "content": response})

        # Check if the response contains the final YAML block
        if "```yaml" in response:
            print_color(BColors.OKGREEN, "\nConfiguration complete! Here is your new `config.yaml`:")
            yaml_content = response.split("```yaml\n")[1].split("```")[0]
            print(yaml_content)
            
            try:
                with open(CONFIG_PATH, 'w') as f:
                    f.write(yaml_content)
                print_color(BColors.OKGREEN, f"\nSuccessfully saved to `{CONFIG_PATH}`.")
            except IOError as e:
                print_color(BColors.FAIL, f"Error saving configuration file: {e}")
            break

        print_color(BColors.OKCYAN, f"\n[Tim Berners-Lee] {response}")
        
        try:
            user_input = input(f"{BColors.BOLD}Your response: {BColors.ENDC}")
            if user_input.lower() in ['exit', 'quit']:
                print_color(BColors.WARNING, "Setup aborted.")
                break
            conversation_history.append({"role": "user", "content": user_input})
        except KeyboardInterrupt:
            print_color(BColors.WARNING, "\nSetup aborted by user.")
            break

if __name__ == "__main__":
    # Check for API key before starting
    if not os.getenv("ANTHROPIC_API_KEY"):
         print_color(BColors.FAIL, "ANTHROPIC_API_KEY not found in environment variables or .env file.")
         print_color(BColors.WARNING, "Please add it to your .env file to use the interactive setup.")
    else:
        asyncio.run(run_setup())
```
---
### File: `Dockerfile`

```dockerfile
# Use an official Python runtime as a parent image
FROM python:3.11-slim

# Set the working directory in the container
WORKDIR /app

# Create a non-root user and switch to it
RUN useradd -m appuser
USER appuser

# Copy only the dependency files first to leverage Docker layer caching
COPY --chown=appuser:appuser pyproject.toml poetry.lock* ./
COPY --chown=appuser:appuser requirements.txt ./

# Install dependencies
# Using requirements.txt for simplicity in this setup, but poetry is also configured
RUN pip install --no-cache-dir --user -r requirements.txt

# Copy the rest of the application code
COPY --chown=appuser:appuser . .

# Expose the port the app runs on
EXPOSE 8000

# Add the user's local bin to the PATH
ENV PATH="/home/appuser/.local/bin:${PATH}"

# Run the application
CMD ["uvicorn", "blueprint.src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```
---
### File: `docker-compose.yml`

```yaml
version: '3.8'

services:
  blueprint:
    build: .
    container_name: blueprint-v2
    restart: unless-stopped
    ports:
      - "8000:8000"
    volumes:
      # Mount the projects directory to persist outputs on the host
      - ./projects:/app/projects
      # Mount the source code for live-reloading during development
      # For production, you would typically not mount the source code
      - ./blueprint:/app/blueprint
    env_file:
      - .env
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8000 || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 20s

volumes:
  projects:
```
---
### File: `install.sh`

```bash
#!/bin/bash
set -e

# This script builds and runs the Blueprint v2.0.1 application using Docker.

# --- Functions ---
print_msg() {
    COLOR=$1
    MSG=$2
    case "$COLOR" in
        "green") echo -e "\033[0;32m${MSG}\033[0m" ;;
        "red") echo -e "\033[0;31m${MSG}\033[0m" ;;
        "yellow") echo -e "\033[0;33m${MSG}\033[0m" ;;
        *) echo "${MSG}" ;;
    esac
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# --- Pre-flight Checks ---
print_msg "yellow" "--- Running Pre-flight Checks ---"

if ! command_exists docker; then
    print_msg "red" "Error: Docker is not installed. Please install Docker to continue."
    exit 1
fi
print_msg "green" "✅ Docker is installed."

# Check for 'docker compose' (v2 syntax) first, then fall back to 'docker-compose'
if docker compose version >/dev/null 2>&1; then
    DOCKER_COMPOSE_CMD="docker compose"
elif command_exists docker-compose; then
    DOCKER_COMPOSE_CMD="docker-compose"
else
    print_msg "red" "Error: Docker Compose is not installed. Please install Docker Compose (v2 'docker compose' is recommended) to continue."
    exit 1
fi
print_msg "green" "✅ Docker Compose is available (using '$DOCKER_COMPOSE_CMD')."


if [ ! -f .env ]; then
    print_msg "yellow" "Warning: .env file not found. Copying from .env.example."
    cp .env.example .env
    print_msg "green" "✅ .env file created. Please edit it with your API keys."
fi
print_msg "green" "✅ .env file found."


# --- Installation ---
print_msg "yellow" "\n--- Starting Blueprint v2.0.1 Installation ---"

if [ "$($DOCKER_COMPOSE_CMD ps -q)" ]; then
    print_msg "yellow" "Stopping existing Blueprint containers..."
    $DOCKER_COMPOSE_CMD down
fi

print_msg "yellow" "Building Docker image..."
$DOCKER_COMPOSE_CMD build
if [ $? -ne 0 ]; then
    print_msg "red" "Error: Docker image build failed."
    exit 1
fi
print_msg "green" "✅ Docker image built successfully."

print_msg "yellow" "Starting Blueprint container..."
$DOCKER_COMPOSE_CMD up -d
if [ $? -ne 0 ]; then
    print_msg "red" "Error: Failed to start the Docker container."
    exit 1
fi

# --- Post-installation ---
print_msg "green" "\n--- ✅ Installation Complete ---"
print_msg "green" "Blueprint v2.0.1 is now running!"
print_msg "green" "Access the web UI at: http://localhost:8000"
print_msg "yellow" "\nFirst time setup? Run the interactive configuration wizard:"
print_msg "yellow" "python3 -m blueprint.setup.berners_lee"
print_msg "yellow" "\nTo view logs, run: $DOCKER_COMPOSE_CMD logs -f"
print_msg "yellow" "To stop the application, run: $DOCKER_COMPOSE_CMD down"

exit 0
```
---
### File: `pyproject.toml`

```toml
[tool.poetry]
name = "blueprint-v2"
version = "2.0.1"
description = "Conversational Multi-Agent Development System"
authors = ["Blueprint Senior Developer"]
readme = "README.md"

[tool.poetry.dependencies]
python = "^3.11"
fastapi = "^0.111.0"
uvicorn = {extras = ["standard"], version = "^0.30.1"}
websockets = "^12.0"
python-dotenv = "^1.0.1"
pyyaml = "^6.0.1"
pydantic = "^2.8.2"
openai = "^1.35.13"
google-generativeai = "^0.7.2"
anthropic = "^0.29.0"
tenacity = "^8.5.0"

[tool.poetry.group.dev.dependencies]
pytest = "^8.2.2"
pytest-asyncio = "^0.23.7"
httpx = "^0.27.0"
pytest-mock = "^3.14.0"

[build-system]
requires = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```
---
### File: `requirements.txt`

```txt
# This file is for Docker builds and environments without Poetry.
# It should be kept in sync with pyproject.toml
fastapi==0.111.0
uvicorn[standard]==0.30.1
websockets==12.0
python-dotenv==1.0.1
PyYAML==6.0.1
pydantic==2.8.2
openai==1.35.13
google-generativeai==0.7.2
anthropic==0.29.0
tenacity==8.5.0
```
---
### File: `README.md`

```md
# Blueprint v2.0.1

Blueprint is a conversational multi-agent system designed to create complete, production-ready digital assets from a natural language conversation. You interact with a Project Manager AI to define requirements, and a specialized team of AI agents collaborates to build, synthesize, and review the final product.

This version (v2.0.1) implements the core conversational workflow, supports multi-modal inputs (audio and file attachments), and provides a simple, intuitive web interface for interaction.

## Core Workflow

The system follows a robust, multi-phase process designed to prevent "prompt drift" and ensure high-quality output:

1.  **Requirements Gathering**: You chat with a Project Manager (PM) AI to define what you want to build. You can type, speak, or attach files. The entire verbatim conversation becomes the requirements.
2.  **Genesis**: A team of developers (1 Senior, 3 Juniors) work in parallel to create independent solutions. This can be run for multiple rounds to allow for cross-pollination of ideas.
3.  **Synthesis**: The Senior Developer analyzes all Genesis solutions and synthesizes them into a single, superior version.
4.  **Review & Revise**: The Junior team reviews the synthesized version and provides critiques. If consensus isn't reached, the feedback is sent back to the Senior for revision. This loop continues until the team approves the final product.
5.  **Final Output**: The approved asset is presented to you, with all files available for viewing in the UI.

## Features

-   **Multi-Modal Conversational Interface**: A chat-based UI for defining project requirements using text, voice, and file attachments.
-   **Stateful Multi-Agent System**: A reliable backend orchestrator that manages the complex workflow.
-   **Real-time Progress**: A live-updating UI that shows the status of each build phase via WebSockets.
-   **Rich Artifact Viewer**: View generated files directly in the UI, with **iframe support** for rendering HTML, PDFs, images, and other rich content.
-   **Interactive Setup**: A friendly, conversational CLI (`berners_lee.py`) to guide you through `config.yaml` setup, now with dynamic model fetching for better recommendations.
-   **Configurable AI Team**: Easily configure the models used for each role via `blueprint/config.yaml`.
-   **Multi-Provider Support**: Integrates with OpenAI, Google, Anthropic, and Together.ai.
-   **Dockerized**: The entire application is containerized for easy, consistent, and isolated deployment.
-   **Tested Workflow**: Includes an integration test suite for the core orchestration logic.

## Installation and Usage

### Prerequisites

-   [Docker](https://docs.docker.com/get-docker/)
-   [Docker Compose](https://docs.docker.com/compose/install/) (v2 `docker compose` is recommended)
-   Python 3.11+ (for the interactive setup script and tests)

### Quick Start

1.  **Clone the Repository**:
    ```bash
    git clone <repository_url>
    cd <repository_folder>
    ```

2.  **Configure API Keys**:
    A `.env.example` file is provided. Copy it to `.env` and add your API keys. You only need to provide keys for the providers you intend to use.
    ```bash
    cp .env.example .env
    # Now edit the .env file with your keys
    nano .env
    ```

3.  **Run the Interactive Setup (Recommended)**:
    Use our "Tim Berners-Lee" setup assistant to configure your `config.yaml` file. You will need an Anthropic API key for this step.
    ```bash
    pip install -r requirements.txt # Install dependencies for the script
    python -m blueprint.setup.berners_lee
    ```

4.  **Run the Installation Script**:
    This script will check prerequisites, build the Docker image, and start the application.
    ```bash
    chmod +x install.sh
    ./install.sh
    ```

5.  **Access the Web UI**:
    Once the container is running, open your web browser and navigate to:
    **[http://localhost:8000](http://localhost:8000)**

### How to Use

1.  Click **"+ New Project"**.
2.  Begin chatting with the Project Manager. Use the text input, the microphone button `🎤` to record audio, or the paperclip `📎` to attach files.
3.  When you are satisfied with the requirements, type `/build` and press send.
4.  Monitor the build progress in the status panel.
5.  When complete, view the final files in the "Artifacts" panel on the right.

### Managing the Application

-   **View Logs**: `docker compose logs -f`
-   **Stop**: `docker compose down`
-   **Run Tests**: `pytest`

## Future Improvements & Considerations

-   **Native Executables**: For a more traditional desktop application feel, tools like [PyInstaller](https://pyinstaller.org/) could be used to create self-installable executables for Windows and macOS. This would be an alternative distribution method to Docker.
-   **Local Models & Hardware Detection**: A future version will enhance the setup process to detect local hardware (e.g., VRAM) and assist the user in downloading and configuring local LLM models (e.g., GGUF via Ollama or llama.cpp) for offline or private use.

## Project Structure

```
.
├── blueprint/
│   ├── contexts/         # System prompts for AI roles
│   ├── frontend/         # HTML, CSS, JS for the web UI
│   ├── setup/            # Interactive setup script
│   └── src/              # Python source code
│       ├── api/          # WebSocket connection manager
│       ├── config/       # Pydantic settings and config loader
│       ├── llm/          # Multi-provider LLM client
│       ├── media/        # Audio transcription logic
│       ├── storage/      # Filesystem utilities
│       └── workflow/     # Core workflow orchestrator and phase logic
├── projects/             # Output directory for generated projects
├── tests/                # Pytest test suite
│   ├── assets/           # Test data, including mock LLM responses
└── ... (config files)
```
```
---
### File: `.env.example`

```dotenv
# API Keys for Blueprint LLM Providers
# You only need to fill in the keys for the models you configure in config.yaml.
# Get your keys from the respective provider websites.

# Required for audio transcription and if using OpenAI models
OPENAI_API_KEY=""

# Required if using Google models
GOOGLE_API_KEY=""

# Required for the interactive setup script and if using Anthropic models
ANTHROPIC_API_KEY=""

# Required if using Together.ai models
TOGETHER_API_KEY=""

# Required if using xAI models
XAI_API_KEY=""
```
---
### File: `tests/assets/sample_response.md`

```md
This is some conversational text that should be ignored by the parser.

## File: src/main.py
```python
# This is the main python file.
def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()
```

Here is some more text.

## File: README.md
```markdown
# My Project

This is a sample project.
```

And a final file.

## File: `data/notes.txt`
```
Some notes here.
```
```
---
### File: `tests/assets/workflow/genesis_junior.md`

```md
## File: junior_snake.py
```python
# Junior Developer's Snake Game
# A simple, functional implementation.

import pygame
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 600, 400
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Junior's Snake Game")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Game variables
snake_pos = [100, 50]
snake_body = [[100, 50], [90, 50], [80, 50]]
food_pos = [random.randrange(1, (WIDTH//10)) * 10, random.randrange(1, (HEIGHT//10)) * 10]
food_spawn = True
direction = 'RIGHT'
change_to = direction
score = 0

# Game loop
run = True
while run:
    pygame.time.delay(100)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    
    win.fill(BLACK)
    
    # Display Score
    font = pygame.font.SysFont('times new roman', 20)
    score_surface = font.render(f"Score : {score}", True, WHITE)
    win.blit(score_surface, (10, 10))

    # Snake and Food
    for pos in snake_body:
        pygame.draw.rect(win, GREEN, pygame.Rect(pos[0], pos[1], 10, 10))
    pygame.draw.rect(win, RED, pygame.Rect(food_pos[0], food_pos[1], 10, 10))

    pygame.display.update()
```
```
---
### File: `tests/assets/workflow/genesis_senior.md`

```md
## File: senior_snake.py
```python
# Senior Developer's Snake Game
# A more structured implementation with classes.

import pygame
import sys
import random

class Snake:
    def __init__(self):
        self.length = 1
        self.positions = [((600 // 2), (400 // 2))]
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        self.color = (0, 255, 0)

    def get_head_position(self):
        return self.positions[0]

    def turn(self, point):
        if self.length > 1 and (point[0] * -1, point[1] * -1) == self.direction:
            return
        else:
            self.direction = point

    def move(self):
        cur = self.get_head_position()
        x, y = self.direction
        new = (((cur[0] + (x*GRID_SIZE)) % 600), (cur[1] + (y*GRID_SIZE)) % 400)
        if len(self.positions) > 2 and new in self.positions[2:]:
            self.reset()
        else:
            self.positions.insert(0, new)
            if len(self.positions) > self.length:
                self.positions.pop()

    def reset(self):
        self.length = 1
        self.positions = [((600 // 2), (400 // 2))]
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])

    def draw(self, surface):
        for p in self.positions:
            r = pygame.Rect((p[0], p[1]), (GRID_SIZE, GRID_SIZE))
            pygame.draw.rect(surface, self.color, r)
            pygame.draw.rect(surface, (0, 0, 0), r, 1)

class Food:
    def __init__(self):
        self.position = (0, 0)
        self.color = (255, 0, 0)
        self.randomize_position()

    def randomize_position(self):
        self.position = (random.randint(0, GRID_WIDTH-1) * GRID_SIZE, random.randint(0, GRID_HEIGHT-1) * GRID_SIZE)

    def draw(self, surface):
        r = pygame.Rect((self.position[0], self.position[1]), (GRID_SIZE, GRID_SIZE))
        pygame.draw.rect(surface, self.color, r)
        pygame.draw.rect(surface, (0, 0, 0), r, 1)

GRID_SIZE = 10
GRID_WIDTH = 600 // GRID_SIZE
GRID_HEIGHT = 400 // GRID_SIZE
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

def main():
    pygame.init()
    screen = pygame.display.set_mode((600, 400))
    surface = pygame.Surface(screen.get_size())
    surface = surface.convert()

    snake = Snake()
    food = Food()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        surface.fill((255, 255, 255))
        snake.move()
        snake.draw(surface)
        food.draw(surface)
        screen.blit(surface, (0,0))
        pygame.display.update()

if __name__ == '__main__':
    main()
```
## File: README.md
```md
# Senior's Snake Game

This is a more robust implementation of the Snake game using classes to separate concerns.
```
```
---
### File: `tests/assets/workflow/pm_response.json`

```json
{
  "instructions_for_dev_team": "Build a simple snake game using Python and Pygame. The game should be playable and demonstrate the core mechanics of snake."
}
```
---
### File: `tests/assets/workflow/review_approve.json`

```json
{
  "approved": true,
  "critique": "This revised version is excellent. It combines the clean structure of the senior's initial design with the simplicity and clarity of the junior's approach. The code is well-commented and all requirements are met. I approve this for final release."
}
```
---
### File: `tests/assets/workflow/review_reject.json`

```json
{
  "approved": false,
  "critique": "The synthesized version is overly complex. It uses classes, which is good, but it's not clear how to run the game. There is no main game loop. Please refactor this to include a clear entry point and a main function that runs the game loop, handles events, and updates the display. Also, the README is missing."
}
```
---
### File: `tests/assets/workflow/synthesis_1_initial.md`

```md
## File: snake_game.py
```python
# Synthesized Snake Game - Version 1
# This combines the class-based approach from the senior with the junior's simple style.
# NOTE: This version is intentionally flawed for the test case (missing game loop).

import pygame
import sys
import random

class Snake:
    def __init__(self):
        self.length = 1
        self.positions = [((600 // 2), (400 // 2))]
        self.direction = random.choice([(0, -1), (0, 1), (-1, 0), (1, 0)])
        self.color = (0, 255, 0)

    def get_head_position(self):
        return self.positions[0]

    def turn(self, point):
        if self.length > 1 and (point[0] * -1, point[1] * -1) == self.direction:
            return
        else:
            self.direction = point

    def move(self):
        cur = self.get_head_position()
        x, y = self.direction
        new = (((cur[0] + (x*10)) % 600), (cur[1] + (y*10)) % 400)
        if len(self.positions) > 2 and new in self.positions[2:]:
            self.reset()
        else:
            self.positions.insert(0, new)
            if len(self.positions) > self.length:
                self.positions.pop()

    def reset(self):
        self.length = 1
        self.positions = [((600 // 2), (400 // 2))]

    def draw(self, surface):
        for p in self.positions:
            r = pygame.Rect((p[0], p[1]), (10, 10))
            pygame.draw.rect(surface, self.color, r)

class Food:
    def __init__(self):
        self.position = (0, 0)
        self.color = (255, 0, 0)
        self.randomize_position()

    def randomize_position(self):
        self.position = (random.randint(0, 59) * 10, random.randint(0, 39) * 10)

    def draw(self, surface):
        r = pygame.Rect((self.position[0], self.position[1]), (10, 10))
        pygame.draw.rect(surface, self.color, r)

# Missing main game loop
```
```
---
### File: `tests/assets/workflow/synthesis_2_revised.md`

```md
## File: snake_game_final.py
```python
# Synthesized Snake Game - Final Revised Version
# Addresses feedback from the junior team by adding a proper game loop and comments.

import pygame
import sys
import random

# --- Constants ---
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
GRID_SIZE = 20
GRID_WIDTH = SCREEN_WIDTH // GRID_SIZE
GRID_HEIGHT = SCREEN_HEIGHT // GRID_SIZE
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

# --- Classes ---
class Snake:
    """Represents the snake."""
    def __init__(self):
        self.length = 1
        self.positions = [((SCREEN_WIDTH // 2), (SCREEN_HEIGHT // 2))]
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        self.color = (0, 170, 0)
        self.score = 0

    def get_head_position(self):
        return self.positions[0]

    def turn(self, point):
        if self.length > 1 and (point[0] * -1, point[1] * -1) == self.direction:
            return
        self.direction = point

    def move(self):
        cur = self.get_head_position()
        x, y = self.direction
        new = ((cur[0] + (x * GRID_SIZE)), (cur[1] + (y * GRID_SIZE)))
        
        # Game over conditions
        if new[0] < 0 or new[0] >= SCREEN_WIDTH or new[1] < 0 or new[1] >= SCREEN_HEIGHT or new in self.positions[2:]:
            self.reset()
        else:
            self.positions.insert(0, new)
            if len(self.positions) > self.length:
                self.positions.pop()

    def reset(self):
        self.length = 1
        self.positions = [((SCREEN_WIDTH // 2), (SCREEN_HEIGHT // 2))]
        self.score = 0
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])

    def ate_food(self, food_position):
        if self.get_head_position() == food_position:
            self.length += 1
            self.score += 1
            return True
        return False

    def draw(self, surface):
        for p in self.positions:
            r = pygame.Rect((p[0], p[1]), (GRID_SIZE, GRID_SIZE))
            pygame.draw.rect(surface, self.color, r)

class Food:
    """Represents the food."""
    def __init__(self):
        self.position = (0, 0)
        self.color = (200, 0, 0)
        self.randomize_position()

    def randomize_position(self):
        self.position = (random.randint(0, GRID_WIDTH - 1) * GRID_SIZE, random.randint(0, GRID_HEIGHT - 1) * GRID_SIZE)

    def draw(self, surface):
        r = pygame.Rect((self.position[0], self.position[1]), (GRID_SIZE, GRID_SIZE))
        pygame.draw.rect(surface, self.color, r)

# --- Main Game Logic ---
def main():
    """Main function to run the game."""
    pygame.init()
    clock = pygame.time.Clock()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), 0, 32)
    surface = pygame.Surface(screen.get_size()).convert()
    
    snake = Snake()
    food = Food()
    
    font = pygame.font.SysFont("monospace", 16)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    snake.turn(UP)
                elif event.key == pygame.K_DOWN:
                    snake.turn(DOWN)
                elif event.key == pygame.K_LEFT:
                    snake.turn(LEFT)
                elif event.key == pygame.K_RIGHT:
                    snake.turn(RIGHT)
        
        snake.move()
        if snake.ate_food(food.position):
            food.randomize_position()

        surface.fill((0, 0, 0))
        snake.draw(surface)
        food.draw(surface)
        
        score_text = font.render(f"Score: {snake.score}", 1, (255, 255, 255))
        screen.blit(surface, (0, 0))
        screen.blit(score_text, (5, 10))
        pygame.display.update()
        clock.tick(10)

if __name__ == '__main__':
    main()
```
## File: index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pygame Snake</title>
    <style>
        body { font-family: sans-serif; text-align: center; }
    </style>
</head>
<body>
    <h1>Pygame Snake Game</h1>
    <p>This project was generated by Blueprint. To run the game, execute the python script:</p>
    <pre><code>python snake_game_final.py</code></pre>
</body>
</html>
```
## File: README.md
```md
# Final Snake Game

This is the final, approved version of the Snake game. It incorporates feedback from the entire AI team.

## How to Run

1. Make sure you have `pygame` installed:
   ```bash
   pip install pygame
   ```
2. Run the main game file:
   ```bash
   python snake_game_final.py
   ```
```
```
---
### File: `tests/test_config.py`

```python
import pytest
import os
from pydantic import ValidationError
from blueprint.src.config import settings

def test_settings_load_successfully(monkeypatch):
    # Ensure config.yaml exists relative to the test runner's CWD
    # This assumes tests are run from the project root.
    assert os.path.exists(settings.CONFIG_PATH)

    # Mock environment variables
    monkeypatch.setenv("OPENAI_API_KEY", "sk-1234")
    monkeypatch.setenv("GOOGLE_API_KEY", "g-5678")

    # Reload settings to pick up mocked env vars
    loaded_settings = settings.load_settings()

    # Assertions
    assert loaded_settings.team.project_manager == "anthropic/claude-3-5-sonnet-20240620"
    assert loaded_settings.workflow.genesis_rounds == 2
    assert loaded_settings.api_keys.openai == "sk-1234"
    assert loaded_settings.api_keys.google == "g-5678"
    assert loaded_settings.api_keys.anthropic is not None # Should be loaded from .env if present

def test_junior_count_validation():
    # This tests the custom validator in the settings model
    invalid_config_dict = {
        "team": {
            "project_manager": "a/b",
            "senior": "c/d",
            "juniors": {
                "count": 3,
                "models": ["e/f", "g/h"] # Mismatch: count is 3, but only 2 models listed
            }
        },
        "workflow": {"genesis_rounds": 1, "max_review_loops": 1, "approval_threshold": 1.0, "max_retries": 1},
        "output": {"path": "projects"},
        "context_paths": {"project_manager": "a", "senior": "b", "junior": "c", "setup_manager": "d"}
    }
    
    with pytest.raises(ValidationError) as excinfo:
        settings.Settings.model_validate(invalid_config_dict)
    
    assert "must match the specified junior count" in str(excinfo.value)
```
---
### File: `tests/test_filesystem.py`

```python
import pytest
from pathlib import Path
from blueprint.src.storage.filesystem import parse_and_write_files, format_files_for_context, get_project_files_as_dict

@pytest.fixture
def sample_response():
    # It's better to read from a file to keep the test clean
    return (Path(__file__).parent / "assets/sample_response.md").read_text()

@pytest.fixture
def temp_workspace(tmp_path):
    return tmp_path / "test_workspace"

def test_parse_and_write_files(sample_response, temp_workspace):
    # Act
    files_created = parse_and_write_files(sample_response, temp_workspace)

    # Assert
    assert len(files_created) == 3
    
    main_py_path = temp_workspace / "src/main.py"
    readme_path = temp_workspace / "README.md"
    notes_path = temp_workspace / "data/notes.txt"

    assert main_py_path.exists()
    assert readme_path.exists()
    assert notes_path.exists()

    main_content = main_py_path.read_text()
    assert 'print("Hello, World!")' in main_content
    assert not main_content.startswith("```")

    readme_content = readme_path.read_text()
    assert "This is a sample project." in readme_content

def test_format_files_for_context(temp_workspace):
    # Arrange
    src_dir = temp_workspace / "src"
    src_dir.mkdir()
    (src_dir / "app.js").write_text("console.log('hello');")
    (temp_workspace / "index.html").write_text("<h1>Hi</h1>")

    # Act
    context_str = format_files_for_context(temp_workspace)

    # Assert
    assert "## File: index.html" in context_str
    assert "<h1>Hi</h1>" in context_str
    assert "## File: src/app.js" in context_str
    assert "console.log('hello');" in context_str

def test_get_project_files_as_dict(temp_workspace):
    # Arrange
    src_dir = temp_workspace / "src"
    src_dir.mkdir()
    (src_dir / "app.js").write_text("console.log('hello');")
    (temp_workspace / "index.html").write_text("<h1>Hi</h1>")

    # Act
    file_dict = get_project_files_as_dict(temp_workspace)

    # Assert
    assert "index.html" in file_dict
    assert "src/app.js" in file_dict
    assert file_dict["index.html"] == "<h1>Hi</h1>"
    assert file_dict["src/app.js"] == "console.log('hello');"

def test_parse_fallback_to_single_file(temp_workspace):
    # Arrange
    bad_response = "This response has no file blocks."

    # Act
    files_created = parse_and_write_files(bad_response, temp_workspace)

    # Assert
    assert len(files_created) == 1
    fallback_file = temp_workspace / "response.md"
    assert fallback_file.exists()
    assert fallback_file.read_text() == bad_response
```
---
### File: `tests/test_llm_client.py`

```python
import pytest
from unittest.mock import MagicMock, AsyncMock
from blueprint.src.llm.client import LLMClient

@pytest.fixture
def mock_settings(mocker):
    # Mock the settings object to provide controlled API keys and paths
    mock_api_keys = MagicMock()
    mock_api_keys.openai = "fake-openai-key"
    mock_api_keys.google = "fake-google-key"
    
    mocker.patch('blueprint.src.llm.client.settings.api_keys', mock_api_keys)
    mocker.patch('blueprint.src.llm.client.settings.workflow.max_retries', 1)

@pytest.mark.asyncio
async def test_openai_client_generation(mock_settings, mocker):
    # Arrange
    mock_openai_client = AsyncMock()
    mock_response = MagicMock()
    mock_choice = MagicMock()
    mock_message = MagicMock()
    mock_message.content = "OpenAI response"
    mock_choice.message = mock_message
    mock_response.choices = [mock_choice]
    mock_openai_client.chat.completions.create.return_value = mock_response
    
    mocker.patch('openai.AsyncOpenAI', return_value=mock_openai_client)

    # Act
    client = LLMClient("openai/gpt-4")
    response = await client.generate("system prompt", [{"role": "user", "content": "hello"}])
    
    # Assert
    assert response == "OpenAI response"
    mock_openai_client.chat.completions.create.assert_called_once()

@pytest.mark.asyncio
async def test_openai_client_transcription(mock_settings, mocker):
    # Arrange
    mock_openai_client = AsyncMock()
    mock_transcription = MagicMock()
    mock_transcription.text = "This is a transcript."
    mock_openai_client.audio.transcriptions.create.return_value = mock_transcription

    mocker.patch('openai.AsyncOpenAI', return_value=mock_openai_client)

    # Act
    client = LLMClient("openai/whisper-1")
    transcript = await client.transcribe(b"fakedata", "audio.mp3")

    # Assert
    assert transcript == "This is a transcript."
    mock_openai_client.audio.transcriptions.create.assert_called_once_with(
        model="whisper-1",
        file=("audio.mp3", b"fakedata")
    )

def test_invalid_model_identifier():
    with pytest.raises(ValueError) as excinfo:
        LLMClient("invalid-format")
    assert "Invalid model identifier format" in str(excinfo.value)

def test_missing_api_key(mocker):
    mock_api_keys = MagicMock()
    mock_api_keys.openai = None # Ensure key is missing
    mocker.patch('blueprint.src.llm.client.settings.api_keys', mock_api_keys)
    
    with pytest.raises(ValueError) as excinfo:
        LLMClient("openai/gpt-4")
    assert "API key for provider 'openai' is not configured" in str(excinfo.value)
```
---
### File: `tests/test_workflow.py`

```python
import pytest
import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, call

from blueprint.src.workflow.orchestrator import ProjectOrchestrator
from blueprint.src.api.websocket import ConnectionManager
from blueprint.src.config.settings import settings

# Load mock responses from assets
ASSETS_PATH = Path(__file__).parent / "assets" / "workflow"
PM_RESPONSE = (ASSETS_PATH / "pm_response.json").read_text()
GENESIS_SENIOR = (ASSETS_PATH / "genesis_senior.md").read_text()
GENESIS_JUNIOR = (ASSETS_PATH / "genesis_junior.md").read_text()
SYNTHESIS_1 = (ASSETS_PATH / "synthesis_1_initial.md").read_text()
REVIEW_REJECT = (ASSETS_PATH / "review_reject.json").read_text()
REVIEW_APPROVE = (ASSETS_PATH / "review_approve.json").read_text()
SYNTHESIS_2_REVISED = (ASSETS_PATH / "synthesis_2_revised.md").read_text()

@pytest.fixture
def mock_llm_client(mocker):
    """Mocks the LLMClient to control its responses during the workflow."""
    mock_generate = AsyncMock()
    mocker.patch('blueprint.src.workflow.orchestrator.LLMClient.generate', new=mock_generate)
    mocker.patch('blueprint.src.workflow.phases.LLMClient.generate', new=mock_generate)
    return mock_generate

@pytest.fixture
def mock_connection_manager(mocker):
    """Mocks the ConnectionManager to spy on its calls without real WebSockets."""
    manager = ConnectionManager()
    manager.send_pm_message = AsyncMock()
    manager.send_progress_update = AsyncMock()
    manager.send_build_complete = AsyncMock()
    manager.send_error = AsyncMock()
    return manager

@pytest.mark.asyncio
async def test_full_workflow_with_revision(mock_llm_client, mock_connection_manager, tmp_path):
    """
    Integration test for the entire project workflow, including one round of rejection and revision.
    """
    # --- ARRANGE ---
    # Point settings to the temporary directory for test isolation
    settings.output.path = str(tmp_path)
    # Configure a smaller team for a faster, more predictable test
    settings.team.juniors.count = 2
    settings.team.juniors.models = ["test/junior-1", "test/junior-2"]
    settings.workflow.genesis_rounds = 1 # Only one genesis round
    settings.workflow.approval_threshold = 1.0 # Require 100% approval

    # Set up the sequence of LLM responses for the entire workflow
    mock_llm_client.side_effect = [
        # 1. Initial PM greeting (not part of the build workflow itself)
        "Hello! What can I build for you?", 
        # 2. PM responds to user's `/build` command with instructions
        PM_RESPONSE,
        # 3. Genesis Round 1 (1 Senior + 2 Juniors)
        GENESIS_SENIOR, GENESIS_JUNIOR, GENESIS_JUNIOR,
        # 4. Synthesis Round 1
        SYNTHESIS_1,
        # 5. Review Round 1 (2 Juniors: one rejects, one approves)
        REVIEW_REJECT, REVIEW_APPROVE,
        # 6. Senior Revision (Synthesis Round 2)
        SYNTHESIS_2_REVISED,
        # 7. Review Round 2 (2 Juniors: both approve)
        REVIEW_APPROVE, REVIEW_APPROVE
    ]

    orchestrator = ProjectOrchestrator(mock_connection_manager)
    project_id = "test_project_123"
    mock_websocket = MagicMock()

    # --- ACT ---
    # Simulate the user conversation leading to the build command
    await orchestrator.start_project(project_id, mock_websocket)
    await orchestrator.handle_user_message(project_id, "Build me a snake game.")
    await orchestrator.handle_user_message(project_id, "/build")
    
    # Allow the background build task to complete
    # In a real scenario this runs in the background; here we wait for it.
    project = orchestrator.projects[project_id]
    # Find the asyncio task and await it
    tasks = [t for t in asyncio.all_tasks() if t.get_name() == f"build_task_{project_id}"]
    if tasks:
        await tasks[0]

    # --- ASSERT ---
    # 1. Check LLM was called the correct number of times
    assert mock_llm_client.call_count == 9

    # 2. Check that the file structure was created correctly
    project_path = tmp_path / project_id
    assert (project_path / "genesis_round_1" / "senior" / "senior_snake.py").exists()
    assert (project_path / "genesis_round_1" / "junior_0" / "junior_snake.py").exists()
    assert (project_path / "genesis_round_1" / "junior_1" / "junior_snake.py").exists()
    assert (project_path / "synthesis_round_1" / "snake_game.py").exists()
    assert (project_path / "synthesis_round_2" / "snake_game_final.py").exists()
    assert (project_path / "final_product" / "README.md").exists()
    assert (project_path / "final_product" / "snake_game_final.py").exists()
    assert (project_path / "final_product" / "index.html").exists()

    # 3. Check WebSocket progress updates
    # We expect updates for each phase start and completion
    # Genesis (start, complete), Synthesis (start, complete), Review (start, complete)
    assert mock_connection_manager.send_progress_update.call_count > 5
    
    # Check the details of the final "Review & Revise" completion update
    final_progress_call = mock_connection_manager.send_progress_update.call_args_list[-1]
    final_status = final_progress_call.args[1]
    review_phase_status = next(p for p in final_status['phases'] if p['name'] == 'Review & Revise')
    assert review_phase_status['status'] == 'complete'
    assert "Consensus reached after 2 loops" in review_phase_status['details']

    # 4. Check that the final build artifacts were sent
    mock_connection_manager.send_build_complete.assert_called_once()
    final_artifacts = mock_connection_manager.send_build_complete.call_args.args[1]
    assert "README.md" in final_artifacts
    assert "snake_game_final.py" in final_artifacts
    assert "index.html" in final_artifacts
    assert "How to Run" in final_artifacts["README.md"]

    # 5. Ensure no errors were sent
    mock_connection_manager.send_error.assert_not_called()
```
