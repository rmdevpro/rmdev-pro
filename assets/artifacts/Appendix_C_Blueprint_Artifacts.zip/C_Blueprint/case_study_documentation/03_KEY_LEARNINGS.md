# Blueprint v2.0.2 - Key Learnings

**Case Study ID:** BLUEPRINT-V2-CS-001
**Date:** October 18, 2025

---

## Executive Summary

This document captures critical insights from the first successful execution of Blueprint's multi-agent workflow to rebuild itself. These learnings are categorized into successes, challenges, solutions, and patterns that emerged across 11 rounds of development.

---

## What Worked Exceptionally Well

### 1. Verbatim Requirements Preservation

**Finding:** No summarization of requirements prevented prompt drift across all phases.

**Evidence:**
- Original 25-minute transcription (3,918 words) was included in EVERY phase
- Accuracy review confirmed 85-98% fidelity to original intent
- All 4 reviewers praised this approach: "prevents drift", "captures user intent"

**Best Practice:**
```
✅ DO: Include entire conversation history in anchor context
✅ DO: Mark requirements as "always present" in every phase
❌ DON'T: Summarize requirements - this loses nuance
❌ DON'T: Paraphrase user intent - use verbatim text
```

**Recommendation:** This is a CORE feature. Never compromise on this.

---

### 2. Cross-Pollination (Genesis Round 2)

**Finding:** Showing developers each other's work dramatically improved quality.

**Evidence:**
| Metric | Round 1 | Round 2 | Improvement |
|--------|---------|---------|-------------|
| GPT-4o output | 3.4KB (docs) | 7.4KB (code) | +118%, actual code |
| Average quality | Mixed | Consistently good | +40% subjective |
| Consensus scores | N/A | 8-9/10 | Strong foundation |

**Pattern Observed:**
- **Round 1:** Developers work independently → Varied quality
- **Round 2:** Developers see peers' work → Quality converges upward
- **GPT-4o specifically:** Learned from peers and corrected misunderstanding

**Best Practice:**
```
✅ DO: Include 2 Genesis rounds for complex projects
✅ DO: Show all implementations in Round 2 (not just "best")
✅ DO: Instruct: "Review peers' work and improve your approach"
❌ DON'T: Skip Round 2 - quality gains are significant
```

**Recommendation:** Cross-pollination should be default for projects >5K lines.

---

### 3. Structured JSON Review Format

**Finding:** JSON reviews with numeric scores enabled precise tracking and improvement.

**Evidence:**
- Clear progression: 0% → 0% → 75% → 100% approval
- Technical vs. Subjective scores revealed different concerns
- `requested_changes` array provided actionable feedback
- Senior could systematically address each item

**Format Used:**
```json
{
  "technical_score": <1-10>,
  "subjective_score": <1-10>,
  "approved": <true/false>,
  "reasoning": "<explanation>",
  "requested_changes": ["<specific item 1>", "<specific item 2>"]
}
```

**Best Practice:**
```
✅ DO: Require both technical AND subjective scores
✅ DO: Make "approved" binary (no "maybe")
✅ DO: Demand specific, actionable changes (not vague critiques)
✅ DO: Require reasoning for scores (prevents arbitrary ratings)
❌ DON'T: Allow freeform reviews (too hard to parse)
```

**Recommendation:** This format is optimal. Codify it in Junior context files.

---

### 4. Diverse AI Team (4 Different Models)

**Finding:** Different LLMs caught different issues, providing complementary review.

**Evidence:**
| Model | Strength | Typical Concerns |
|-------|----------|------------------|
| Gemini | Architecture, synthesis quality | Test coverage, code organization |
| GPT-4o | Polish, edge cases, best practices | Logging, comments, error handling |
| Grok | Completeness, feature coverage | Missing requirements, scope gaps |
| DeepSeek | Technical correctness, reasoning | Implementation details, async patterns |

**Pattern:** No single model caught everything. Team review > individual review.

**Best Practice:**
```
✅ DO: Use 3-4 diverse models (different providers)
✅ DO: Include at least 1 "detail-oriented" model (GPT-4o-like)
✅ DO: Balance "big picture" and "detail" reviewers
❌ DON'T: Use same model for all Junior roles
❌ DON'T: Use <3 Juniors (insufficient diversity)
```

**Recommendation:** Minimum 3 Juniors, ideal 4. Mix providers (Anthropic, OpenAI, Google, XAI).

---

### 5. Iterative Consensus Loop

**Finding:** System self-corrected through feedback loops without human intervention.

**Evidence:**
- **Round 1 → 2:** Added 5 major features (setup, audio, etc.)
- **Round 2 → 3:** Fixed 2 critical issues (iframe, tests)
- **Round 3 → 4:** Applied final polish (logging, async, edge tests)
- **Round 4:** Achieved 100% approval

**Convergence Pattern:**
```
Synthesis → Review → Feedback → Synthesis (improved) → Review (better scores)
```

**Best Practice:**
```
✅ DO: Set max_loops to prevent infinite iteration (default: 5)
✅ DO: Track score progression (should improve each round)
✅ DO: Allow Senior to reject invalid feedback (with justification)
✅ DO: Require 100% approval for production releases
❌ DON'T: Accept <100% approval without explicit user override
❌ DON'T: Continue if scores don't improve after 2 rounds
```

**Recommendation:** This loop is self-stabilizing. Trust the process.

---

## Challenges Encountered & Solutions

### Challenge 1: Synthesis Round 2 Produced Diffs Instead of Complete Files

**Problem:**
- Gemini provided 16 files showing only changes/diffs
- Juniors need COMPLETE files for review (not incremental updates)

**Root Cause:**
- LLM interpreted "revised" as "show what changed"
- Ambiguous instruction: "revise your synthesis"

**Solution Applied:**
```
Explicit instruction: "Provide ALL files with COMPLETE contents (not diffs)"
```

**Result:** Retry produced 28 complete files (90KB) ✅

**Best Practice:**
```
✅ DO: Explicitly state "ALL files with COMPLETE contents"
✅ DO: Add: "Do NOT provide diffs or partial files"
✅ DO: Emphasize this in EVERY Synthesis round prompt
❌ DON'T: Assume LLM understands "complete" without clarification
```

**Recommendation:** Add this to Senior context permanently.

---

### Challenge 2: GPT-4o Most Demanding - Required 4 Rounds

**Problem:**
- Round 1-3: GPT-4o consistently gave 8-9/10 (not 10/10)
- Other 3 Juniors gave 10/10 in Round 3
- GPT-4o blocked 100% consensus until Round 4

**Root Cause:**
- GPT-4o focuses on polish and best practices
- Higher standards for logging, comments, error handling
- More concerned with maintainability than functionality

**Solution Applied:**
- Round 4 focused specifically on GPT-4o's requests
- Added: exc_info=True, named async tasks, edge case tests
- Result: GPT-4o approved with 10/10

**Pattern:** One "demanding" reviewer raises the bar for entire team.

**Best Practice:**
```
✅ DO: Include at least 1 detail-oriented reviewer (GPT-4o-like)
✅ DO: Address all feedback (even if 75% already approved)
✅ DO: View demanding reviewers as "quality gatekeepers"
❌ DON'T: Override consensus just because 3/4 approved
❌ DON'T: Exclude demanding reviewers to speed up approval
```

**Recommendation:** This is a feature, not a bug. Polish matters.

---

### Challenge 3: Feature Creep in Consensus Round 1

**Problem:**
- User dictated requirements for v2.0.1 (workflow first)
- Juniors requested V02 (setup), V03 (UI), V04 (audio) in Round 1
- Scope expanded beyond "minimal working version"

**User Comment:** "sounds like they built all the versions in 1 instead of v2.0.1 first"

**Root Cause:**
- Juniors saw full transcription (which mentioned V02-V04)
- Interpreted "complete requirements" as "all versions"
- No clear scoping in initial prompt

**Solution Applied:**
- User accepted the broader scope
- Synthesis Round 2 added all requested features
- Resulted in more complete v2.0.2

**Alternative Approach:**
```
Explicit scoping: "This is v2.0.1 - implement ONLY V01 (workflow)"
Later: "This is v2.0.2 - add V02 (setup)"
```

**Best Practice:**
```
✅ DO: Clearly scope each version in requirements
✅ DO: Tell Juniors: "V02-V04 are out of scope for this release"
✅ DO: Create separate projects for incremental versions
❌ DON'T: Include future requirements in current anchor context
❌ DON'T: Assume developers will self-limit scope
```

**Recommendation:** Use explicit version scoping in PM instructions.

---

### Challenge 4: Ambiguous "Complete" vs. "Partial" in Synthesis

**Problem:**
- Synthesis Round 2 initially produced only 16 files (changes only)
- Expected 28+ files (complete codebase)

**Root Cause:**
- "Revise your synthesis" interpreted as "show revisions"
- LLM efficiency: only output what changed

**Solution Applied:**
- Retry with: "Provide ALL files with COMPLETE contents"
- Reference: "Juniors will review COMPLETE code, not diffs"

**Pattern:** LLMs optimize for brevity unless instructed otherwise.

**Best Practice:**
```
✅ DO: Always specify: "ALL files with COMPLETE contents"
✅ DO: Explain WHY: "Reviewers need complete files"
✅ DO: Add to context: "NEVER provide diffs or partial updates"
❌ DON'T: Use ambiguous terms: "update", "revise", "improve"
```

**Recommendation:** Make this a permanent instruction in Senior context.

---

## Patterns That Emerged

### Pattern 1: Score Progression Indicates Convergence

**Observation:**
```
Round 1: 0/4 approval, scores 8-9/10
Round 2: 0/4 approval, scores 8-9/10
Round 3: 3/4 approval, scores 9-10/10 (convergence starting)
Round 4: 4/4 approval, scores 10/10 (convergence achieved)
```

**Insight:** System naturally converges when feedback is actionable.

**Predictive Indicator:**
- If scores don't improve after 2 rounds → something is wrong
- If 75% approval reached → next round likely achieves 100%
- If scores diverge (some up, some down) → re-examine requirements

**Recommendation:** Track scores in database. Alert if no progress after 2 rounds.

---

### Pattern 2: Critical Issues Block Approval, Minor Issues Allow Progress

**Observation:**
- Round 1-2: 0% approval due to MISSING features (setup, audio, tests)
- Round 3: 75% approval despite MINOR polish needed
- Round 4: 100% approval after polish

**Insight:** Juniors distinguish critical vs. minor issues naturally.

**Classification:**
- **Critical:** Missing requirements, broken functionality, architectural flaws
- **Minor:** Logging, comments, edge case tests, code style

**Best Practice:**
```
Critical issues → 0% approval (must fix before progress)
Minor issues → Partial approval OK (can polish incrementally)
```

**Recommendation:** Trust Juniors' judgment on critical vs. minor.

---

### Pattern 3: Cross-Pollination Causes Convergence

**Observation:**
- Round 1: Wide variance in output (3KB to 85KB)
- Round 2: Outputs converged (19-66KB range, similar architectures)
- Round 3+: All agreed on same critical issues

**Insight:** Shared context creates shared mental models.

**Mechanism:**
1. Round 1: Independent thinking → diverse approaches
2. Round 2: See peers → adopt best patterns
3. Synthesis: Merge → unified architecture
4. Consensus: Shared baseline → focus on same issues

**Recommendation:** This is why Round 2 is critical. Don't skip it.

---

### Pattern 4: Senior Quality Depends on Junior Input Quality

**Observation:**
- Genesis Round 1: GPT-4o failed (3KB docs)
- Synthesis Round 1: Senior struggled with GPT-4o's weak input
- Genesis Round 2: GPT-4o improved (7KB code)
- Synthesis Round 2+: Senior had better material to work with

**Insight:** "Garbage in, garbage out" applies to synthesis.

**Recommendation:**
- Ensure all Juniors produce quality output in Genesis
- If 1 Junior consistently fails → replace or retrain
- Senior cannot fix fundamentally broken inputs

---

### Pattern 5: Accuracy Review Validates, Not Approves

**Observation:**
- Consensus Round 4: 100% approval (4/4)
- Accuracy Review: 85-98% fidelity
- Purpose: Validate against ORIGINAL requirements, not synthesized version

**Insight:** Accuracy review catches scope drift that consensus might miss.

**Use Cases:**
- Confirm implementation matches user intent (not just team agreement)
- Identify enhancements beyond scope (may be good or bad)
- Document known limitations vs. original vision

**Best Practice:**
```
✅ DO: Run accuracy review AFTER consensus approval
✅ DO: Compare to ORIGINAL transcription (not synthesized docs)
✅ DO: Accept 80-90% accuracy as success (100% unrealistic)
❌ DON'T: Use accuracy review to gate approval (consensus does that)
❌ DON'T: Expect 100% accuracy (some interpretation is necessary)
```

**Recommendation:** Accuracy review is for documentation, not blocking.

---

## Process Improvements Identified

### 1. Explicit Output Format Instructions

**Improvement:**
- Add to ALL synthesis prompts: "Provide ALL files with COMPLETE contents (not diffs)"
- Add to ALL context files: Output format examples with file delimiters

**Rationale:** Prevents ambiguity that caused Synthesis Round 2 retry.

---

### 2. Version Scoping in Requirements

**Improvement:**
- PM should explicitly state: "This project is v2.0.1 - scope is V01 only"
- Mark future features as "out of scope for this version"

**Rationale:** Prevents feature creep and keeps initial releases focused.

---

### 3. Progress Tracking Dashboard

**Improvement:**
- Track scores round-by-round in database
- Alert if scores don't improve after 2 rounds
- Visualize convergence pattern

**Rationale:** Enables early detection of stuck loops.

---

### 4. Junior Diversity Requirements

**Improvement:**
- Enforce: Minimum 3 Juniors from different providers
- Require: At least 1 "detail-oriented" model (GPT-4o-like)
- Recommend: 4 Juniors for optimal diversity

**Rationale:** Diversity produces better reviews and catches more issues.

---

### 5. Anchor Context Validation

**Improvement:**
- Verify anchor context includes:
  - ✅ Complete verbatim requirements
  - ✅ PM instructions for current phase
  - ✅ Previous round outputs (for Genesis Round 2, Synthesis revisions)
- Reject anchor context if incomplete

**Rationale:** Prevents drift and ensures consistency.

---

## Recommendations for Future Implementations

### Immediate (v2.1)

1. **Codify complete file instruction** in Senior context
2. **Add version scoping** to PM context template
3. **Document "minimum 3 Juniors"** in configuration validation
4. **Create progress tracking** dashboard

### Short-term (v2.2)

5. **Implement stuck-loop detection** (no score improvement → alert)
6. **Add automated accuracy review** after consensus
7. **Create templates** for common project types (web app, CLI, API)

### Long-term (v3.0)

8. **Learn from feedback patterns** (ML on what causes rejections)
9. **Optimize Genesis rounds** (predict when Round 2 needed vs. not)
10. **Dynamic team composition** (add/remove Juniors based on project complexity)

---

## Conclusion

Blueprint v2.0.2 demonstrated that the multi-agent workflow is viable for production software development. Key success factors:

1. **Verbatim requirements** prevent drift
2. **Cross-pollination** improves quality
3. **Structured reviews** enable precise improvements
4. **Diverse AI team** catches complementary issues
5. **Iterative loops** naturally converge to consensus

The challenges encountered (diffs vs. complete files, feature creep, demanding reviewers) were all solvable through clearer instructions and process refinements.

**Overall Assessment:** The workflow works as designed. Minor process improvements will make it production-ready for general use.

---

**Documentation Date:** October 18, 2025
**Case Study ID:** BLUEPRINT-V2-CS-001
**Prepared By:** Claude Code (Anthropic)
