```json
{
  "reviewer": "AI Reviewer",
  "verdict": "ACCEPT",
  "objections": []
}
```