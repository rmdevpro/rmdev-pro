```json
{
  "reviewer": "your-model-name",
  "verdict": "ACCEPT",
  "objections": []
}
```